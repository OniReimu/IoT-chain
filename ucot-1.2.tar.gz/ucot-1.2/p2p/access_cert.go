// Copyright 2015 The go-ethereum Authors
// This file is part of the go-ethereum library.
//
// The go-ethereum library is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// The go-ethereum library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with the go-ethereum library. If not, see <http://www.gnu.org/licenses/>.

package p2p

import (
	"bytes"
	"encoding/gob"
	"errors"
	"fmt"
	"net"
	// "strconv"

	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/log"
	"github.com/ethereum/go-ethereum/p2p/discover"
)

const (
	Idendity_ip_addr = "172.31.0.40:33333"
)

// joining
func sendRequest(conn net.Conn, nodeID discover.NodeID, access []byte, nonce []byte, reqNodeID discover.NodeID) {

	// var output []byte
	// output = append(output, []byte{0}...)
	// output = append(output, access...)
	// output = append(output, nonce...)
	// output = append(output, nodeID[:]...)
	// output = append(output, reqNodeID[:]...)

	output := make([]byte, 1+md5Len*2+shaLen+pubLen*2)
	n := copy(output, []byte{0})
	n += copy(output[n:], access)
	n += copy(output[n:], nonce)
	n += copy(output[n:], nodeID[:])
	copy(output[n:], reqNodeID[:])

	_, err := conn.Write(output)
	if err != nil {
		log.Trace("Sending error", "err", err)
		conn.Close()
	}
}

func getAccess(nodeID discover.NodeID, access []byte, nonce []byte, reqNodeID discover.NodeID) (bool, error) {
	log.Trace("Check nodeID from request", "id", common.ToHex(reqNodeID[:]))
	// if net.ParseIP(Idendity_ip_addr) == nil {
	// 	return false, errors.New("Invalid Server IP Address")
	// }
	tcpAddr, err := net.ResolveTCPAddr("tcp", Idendity_ip_addr)
	if err != nil {
		return false, err
	}
	conn, err := net.DialTCP("tcp", nil, tcpAddr)
	if err != nil {
		return false, err
	}
	go sendRequest(conn, nodeID, access, nonce, reqNodeID)

	buf := make([]byte, 1)
	flag := []byte{0, 1} // false, true

	_, err = conn.Read(buf)
	if err != nil {
		conn.Close()
		return false, err
	}
	if bytes.Equal(buf[:], flag[:1]) {
		conn.Close()
		return false, errors.New("Incorrent MD5")
	} else if bytes.Equal(buf[:], flag[1:]) {
		conn.Close()
		return true, nil
	} else {
		conn.Close()
		return false, errors.New("Invalid flag")
	}
}

// disconnecting
func update(conn net.Conn, nodeID discover.NodeID, connected map[string]string) error {
	// output := make([]byte, shaLen*2)
	var output []byte

	bts, err := getBytes(connected)
	if err != nil {
		fmt.Println(err.Error())
		return err
	}
	output = append(output, []byte{1}...)
	output = append(output, nodeID[:]...)
	output = append(output, bts...)

	// n := copy(output, accessWithNonce)
	// copy(output[n:], nonce)
	for {
		if _, err := conn.Write(output); err == nil {
			break
		} else {
			log.Trace("Sending error, retrying ...", "err", err)
		}
	}
	log.Trace("Sending successfully")
	return nil
}

// func discRequest(IP string) {
func updateServerDB(nodeID discover.NodeID, connected map[string]string) {
	for id, _ := range connected {
		log.Trace("Check nodeID from updateDB request", "id", id)
	}

	for {
		tcpAddr, err := net.ResolveTCPAddr("tcp", Idendity_ip_addr)
		if err != nil {
			continue
		}
		conn, err := net.DialTCP("tcp", nil, tcpAddr)
		if err != nil {
			continue
		}
		err = update(conn, nodeID, connected)
		if err != nil {
			continue
		}
		break
	}

}

func getBytes(data interface{}) ([]byte, error) {
	var buf bytes.Buffer
	enc := gob.NewEncoder(&buf)
	err := enc.Encode(data)
	if err != nil {
		return nil, err
	}
	return buf.Bytes(), nil
}
