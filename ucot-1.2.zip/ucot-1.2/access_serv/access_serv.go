// Copyright 2015 The go-ethereum Authors
// This file is part of the go-ethereum library.
//
// The go-ethereum library is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// The go-ethereum library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with the go-ethereum library. If not, see <http://www.gnu.org/licenses/>.

package main

import (
	"bytes"
	"encoding/gob"
	"encoding/hex"
	"fmt"
	"net"
	"os"
	// "strconv"
)

// var (
// 	MaxIncomingMessages = 20
// )

func checkError(err error, info string) (res bool) {
	if err != nil {
		fmt.Println(info + " " + err.Error())
		return false
	}
	return true
}

func ToHex(b []byte) string {
	hex := hex.EncodeToString(b)
	if len(hex) == 0 {
		hex = "0"
	}
	return hex
}

func getAccessFromDB(serverID []byte, access []byte, nonce []byte, reqID []byte) []byte {
	// // LAMP interface
	// white list
	fmt.Println("getAccessFromDB()")
	fmt.Println("serverID: ", ToHex(serverID))
	// fmt.Println("serverIP: ", ipLightServer)

	fmt.Println("access: ", ToHex(access))
	fmt.Println("nonce: ", ToHex(nonce))
	fmt.Println("reqID: ", ToHex(reqID[:64]))
	fmt.Println()
	return []byte{1} // test
}

func updateDB(serverID []byte, connected map[string]string) {
	// // LAMP interface
	fmt.Println("updateDB()")
	fmt.Println("serverID: ", ToHex(serverID))
	for ip, id := range connected {
		fmt.Println("reqIP:Port", ip, "(Might be trivil)")
		fmt.Println("reqNodeID:", id)
	}
	fmt.Println()
}

func Handler(conn net.Conn) {
	fmt.Println("Connecting from ...", conn.RemoteAddr().String())

	buf := make([]byte, 1024)
	var allowedFlag []byte
	// connected := make(map[string]struct{})
	var connected map[string]string

	_, err := conn.Read(buf)
	if !checkError(err, "conn.Read()") {
		conn.Close()
	}
	flag := buf[:1]
	if bytes.Equal(flag, []byte{0}) {
		// accessLen := strconv.Atoi(string(buf[1]))
		access := buf[1:33] // md5 * 2
		nonce := buf[33:65]
		serverID := buf[65:129]
		reqNodeID := buf[129:]
		allowedFlag = getAccessFromDB(serverID, access, nonce, reqNodeID)

		_, err = conn.Write(allowedFlag)
		conn.Close()

		if !checkError(err, "conn.Write()") {
			conn.Close()
		}
	} else {
		serverID := buf[1:65]
		err = getInterface(buf[65:], &connected)
		if !checkError(err, "getInterface()") {
			conn.Close()
		}
		updateDB(serverID, connected)
		conn.Close()
	}
}

func StartServer(port string) error {
	service := ":" + port
	tcpAddr, err := net.ResolveTCPAddr("tcp", service)
	if !checkError(err, "ResolveTCPAddr()") {
		return err
	}

	l, err := net.ListenTCP("tcp", tcpAddr)
	if !checkError(err, "ListenTCP()") {
		return err
	}

	conns := make(map[string]net.Conn)
	// messages := make(chan []byte, MaxIncomingMessages)

	// go echoHandler(&conns, messages)

	for {
		fmt.Println("Listening ...")
		conn, err := l.Accept()
		if !checkError(err, "Accept()") {
			conn.Close()
			return err
		}
		fmt.Println("Accepting ...")
		conns[conn.RemoteAddr().String()] = conn

		go Handler(conn)
	}

}

func getInterface(bts []byte, data interface{}) error {
	buf := bytes.NewBuffer(bts)
	dec := gob.NewDecoder(buf)
	err := dec.Decode(data)
	if !checkError(err, "Decode()") {
		return err
	}
	return nil
}

func main() {
	if len(os.Args) != 3 {
		fmt.Println("Wrong parameters")
		os.Exit(0)
	}

	if os.Args[1] == "server" && len(os.Args) == 3 {
		StartServer(os.Args[2])
	}
}
