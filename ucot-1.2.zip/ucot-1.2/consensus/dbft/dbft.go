// Copyright 2017 The go-ethereum Authors
// This file is part of the go-ethereum library.
//
// The go-ethereum library is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// The go-ethereum library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with the go-ethereum library. If not, see <http://www.gnu.org/licenses/>.

// Package dbft implements the delegated bft consensus engine.

package dbft

import (
	"bytes"
	"crypto/ecdsa"
	"errors"
	"fmt"
	"io/ioutil"
	"math"
	"math/big"
	"os"
	"path/filepath"
	//"reflect"
	"runtime"
	"sync"
	"time"

	"github.com/ethereum/go-ethereum/accounts"
	"github.com/ethereum/go-ethereum/accounts/keystore"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/consensus"
	"github.com/ethereum/go-ethereum/core/state"
	"github.com/ethereum/go-ethereum/core/types"
	"github.com/ethereum/go-ethereum/core/vm"
	"github.com/ethereum/go-ethereum/crypto"
	"github.com/ethereum/go-ethereum/crypto/sha3"
	"github.com/ethereum/go-ethereum/ethdb"
	"github.com/ethereum/go-ethereum/event"
	"github.com/ethereum/go-ethereum/log"
	"github.com/ethereum/go-ethereum/node"
	"github.com/ethereum/go-ethereum/params"
	"github.com/ethereum/go-ethereum/rlp"
	"github.com/ethereum/go-ethereum/rpc"
	lru "github.com/hashicorp/golang-lru"
)

const (
	checkpointInterval = 1024                    // Number of blocks after which to save the snapshot to the database
	inmemorySnapshots  = 128                     // Number of recent vote snapshots to keep in memory
	inmemorySignatures = 4096                    // Number of recent block signatures to keep in memory
	wiggleTime         = 1000 * time.Millisecond // Random delay (per signer) to allow concurrent signers

	scriptN = 262144
	scriptP = 1
)

// DBFT Delegated Byzantine Fault Tolerance protocol constants.
var (
	blockPeriod = uint64(10) // Default minimum difference between two consecutive block's timestamps
	epochLength = uint64(50) // Default number of blocks after which to checkpoint and record the unattended signers
	MinePeriod  = uint64(0) // Default minimum difference between two mining operation's timestamps

	// Extra consists of extraVanity, SignersList, extraSeal in order.
	extraVanity = 32 // Fixed number of extra-data prefix bytes reserved for signer vanity
	extraSeal   = 65 // Fixed number of extra-data suffix bytes reserved for signer seal

	uncleHash = types.CalcUncleHash(nil)

	diff = big.NewInt(1) // Assume difficulty is one

)

// Various error messages to mark blocks invalid. These should be private to
// prevent engine specific errors from being referenced in the remainder of the
// codebase, inherently breaking if the engine is swapped out. Please put common
// error types into the consensus package.
var (
	// errUnknownBlock is returned when the list of validators is requested for a block
	// that is not part of the local blockchain.
	errUnknownBlock = errors.New("unknown block")

	// errInvalidTx is returned when invalid transactions are found in validation process.
	errInvalidTx = errors.New("invalid transactions involve")

	// errInvalidInitialStae is returned when there is at least one validator having different state from others (h, v).
	errInvalidInitialState = errors.New("not starting from the state")

	// errMissingVanity is returned if a block's extra-data section is shorter than
	// 32 bytes, which is required to store the signer vanity.
	errMissingVanity = errors.New("extra-data 32 byte vanity prefix missing")

	// errMissingSignature is returned if a block's extra-data section doesn't seem
	// to contain a 65 byte secp256k1 signature.
	errMissingSignature = errors.New("extra-data 65 byte suffix signature missing")

	// errExtraSigners is returned if non-checkpoint block contain more than one signer data in
	// their extra-data fields.
	errExtraSigners = errors.New("non-checkpoint block contains more than extra signer list")

	// errExtraUnknownSigners is returned if non-checkpoint block contain an unknown signer data in
	// their extra-data fields.
	errExtraUnknownSigners = errors.New("non-checkpoint block contains an unknown extra signer list")

	// errInvalidMixDigest is returned if a block's mix digest is non-zero.
	errInvalidMixDigest = errors.New("non-zero mix digest")

	// errInvalidUncleHash is returned if a block contains an non-empty uncle list.
	errInvalidUncleHash = errors.New("non empty uncle hash")

	// errInvalidDifficulty is returned if the difficulty of a block is not either
	// of 1 , or if the value does not match the turn of the signer.
	errInvalidDifficulty = errors.New("invalid difficulty")

	// ErrInvalidTimestamp is returned if the timestamp of a block is lower than
	// the previous block's timestamp + the minimum block period.
	ErrInvalidTimestamp = errors.New("invalid timestamp")

	// errUnauthorized is returned if a header is signed by a non-authorized entity.
	errUnauthorized = errors.New("unauthorized")

	// errInvalidVotingChain is returned if an authorization list is attempted to
	// be modified via out-of-range or non-contiguous headers.
	errInvalidSnapShotChain = errors.New("invalid snapshot chain")

	// errInvalidCheckpointSigners is returned if a checkpoint block contains an
	// invalid list of missing signers (i.e. non divisible by 20 bytes, or not the correct
	// ones).
	errInvalidCheckpointSigners = errors.New("invalid signer list on checkpoint block")
)

// SignerFn is a signer callback function to request a hash to be signed by a
// backing account.
// // Sign all the things!
// sighash, err := signFn(accounts.Account{Address: signer}, sigHash(header).Bytes())
type SignerFn func(accounts.Account, []byte) ([]byte, error)

// sigHash returns the hash which is used as input for the DBFT
// signing. It is the hash of the entire header apart from the 65 byte signature
// contained at the end of the extra data.
//
// Note, the method requires the extra data to be at least 65 bytes, otherwise it
// panics. This is done to avoid accidentally using both forms (signature present
// or not), which could be abused to produce different hashes for the same header.
func sigHash(header *types.Header) (hash common.Hash) {
	hasher := sha3.NewKeccak256()

	rlp.Encode(hasher, []interface{}{
		header.ParentHash,
		header.UncleHash,
		header.Coinbase,
		header.Root,
		header.TxHash,
		header.ReceiptHash,
		header.Bloom,
		header.Difficulty,
		header.Number,
		header.GasLimit,
		header.GasUsed,
		header.Time,
		header.Extra[:len(header.Extra)-65], // Yes, this will panic if extra is too short
		// header.Extra[:len(header.Extra)],
		//header.MixDigest,
		header.Nonce,
	})
	hasher.Sum(hash[:0])
	return hash
}

// ecrecover extracts the Ethereum account address from a signed header. If header does not exist, store in the cache
func ecrecover(header *types.Header, sigcache *lru.ARCCache, isLight bool) (common.Address, error) {
	// If the signature's already cached, return that
	hash := header.Hash()
	if address, known := sigcache.Get(hash); known && !isLight { //***
		return address.(common.Address), nil
	}
	// Retrieve the signature from the header extra-data
	if len(header.Extra) < extraSeal {
		return common.Address{}, errMissingSignature
	}
	signature := header.Extra[len(header.Extra)-extraSeal:]

	// Recover the public key and the Ethereum address
	pubkey, err := crypto.Ecrecover(sigHash(header).Bytes(), signature)
	if err != nil {
		return common.Address{}, err
	}
	var signer common.Address
	copy(signer[:], crypto.Keccak256(pubkey[1:])[12:])
	//log.Trace("Can't not find sig in sigcache", "headerhash", hash, "address", common.ToHex(signer[:]))

	if !isLight {
		sigcache.Add(hash, signer)
	}
	return signer, nil
}

func pubKeyrecover(header *types.Header, sig []byte) (common.Address, error) {
	// Recover the public key and the Ethereum address
	pubkey, err := crypto.Ecrecover(sigHash(header).Bytes(), sig)
	if err != nil {
		return common.Address{}, err
	}
	var signer common.Address
	copy(signer[:], crypto.Keccak256(pubkey[1:])[12:])

	return signer, nil
}

func pubKeyrecoverFromChangeV(changeV *ChangeView, sig []byte) (common.Address, error) {
	// Recover the public key and the Ethereum address
	pubkey, err := crypto.Ecrecover(sigchangeV(changeV).Bytes(), sig)
	if err != nil {
		return common.Address{}, err
	}
	var signer common.Address
	copy(signer[:], crypto.Keccak256(pubkey[1:])[12:])

	return signer, nil
}

func pubKeyrecoverFromNewV(newV *NewViewBroadCast, sig []byte) (common.Address, error) { //**
	// Recover the public key and the Ethereum address
	pubkey, err := crypto.Ecrecover(sigBroadcastNewV(newV).Bytes(), sig)
	if err != nil {
		return common.Address{}, err
	}
	var signer common.Address
	copy(signer[:], crypto.Keccak256(pubkey[1:])[12:])

	return signer, nil
}

func getPrivateKey(keydir string, filename string, Addr string, auth string) *ecdsa.PrivateKey {
	// log.Trace("check", "keydir", keydir, "filename", filename, "addr", Addr, "auth", auth)
	ks := keystore.NewKeyStorePassphrase(keydir, scriptN, scriptP)
	key, _ := ks.GetKey(common.HexToAddress(Addr), filename, auth)
	return key.PrivateKey
}

func eliminateSigningField(header *types.Header) *types.Header {
	unsignedHeader := types.CopyHeader(header)

	unsignedHeader.Extra = header.Extra[:32]
	unsignedHeader.Extra = append(unsignedHeader.Extra, make([]byte, 65)...)

	//unsignedHeader.Extra = header.Extra[:len(header.Extra)-65]
	unsignedHeader.MixDigest = types.EmptySigHash
	return unsignedHeader
}

// Dbft is the Delegated Byzantine Fault Tolerance consensus engine
type Dbft struct {
	ctx    *node.ServiceContext
	config *params.DbftConfig
	db     ethdb.Database

	txPool TxPool

	eventMux *event.TypeMux
	events   *event.TypeMuxSubscription
	// eventForBroadcast *event.TypeMuxSubscription //***
	eventForTxPool *event.TypeMuxSubscription //***

	// // See const
	recentsSnaps *lru.ARCCache
	signatures   *lru.ARCCache

	signer common.Address // Ethereum address of the signing key
	signFn SignerFn       // Signer function to authorize hashes with
	lock   sync.RWMutex   // Protects the signer fields

	isLight bool
}

// New creates a Dbft consensus engine with the initial
// signers set to the ones provided by the user.
func New(ctx *node.ServiceContext, config *params.DbftConfig, db ethdb.Database, eventMux *event.TypeMux, isLight bool) *Dbft { //***
	// Set any missing consensus parameters to their defaults
	conf := *config
	if conf.Epoch == 0 {
		conf.Epoch = epochLength
	}
	if conf.Period == 0 {
		conf.Period = blockPeriod
	}
	// if conf.MinePeriod == 0 {
	// 	conf.MinePeriod = MinePeriod
	// }
	// // Allocate the sigs caches and create the engine
	recentsSnaps, _ := lru.NewARC(inmemorySnapshots)
	signatures, _ := lru.NewARC(inmemorySignatures)

	//log.Trace("Returning a DBFT instance.")

	return &Dbft{
		ctx:    ctx,
		config: &conf,
		db:     db,

		eventMux: eventMux,
		// events:            eventMux.Subscribe(GetPrepareReqEvent{}, GetPrepareRespEvent{}, GetChangeViewEvent{}, GetAdvertToCloseEvent{}, GetAdvertToNewViewEvent{}, sendBackToLoopEvent{}, GetTxPoolEvent{}), //***                                                                                     //***
		// eventForBroadcast: eventMux.Subscribe(GetDelegatedResultEvent{}),
		eventForTxPool: eventMux.Subscribe(GetTxPoolEvent{}),
		recentsSnaps:   recentsSnaps,
		signatures:     signatures,
		isLight:        isLight, // ***
	}
}

func (d *Dbft) getNodeConfig() (string, string, string, string, error) {
	var index int
	checkFileName := func(files []os.FileInfo) bool {
		var count int
		for _, f := range files {
			if f.Name()[:3] == "UTC" {
				count += 1
			}
			if count > 1 {
				return false
			}
		}
		if count == 0 {
			return false
		}
		return true
	}

	keydir := d.ctx.GetConfig().KeystoreDir()
	files, err := ioutil.ReadDir(keydir)
	if err != nil {
		return "", "", "", "", errors.New("Can't read the keystore file")
	}
	if len(files) == 0 {
		return "", "", "", "", errors.New("File does not exist")
	}
	if !checkFileName(files) {
		return "", "", "", "", errors.New("Exist more than one keystore files or invalid file name")
	}
	filename := filepath.Join(keydir, files[0].Name()) // Only one file
	Addr := filename[len(filename)-40:]
	if !addrInSlice(common.HexToAddress(Addr), AddressList()) {
		return "", "", "", "", errors.New("Local node is not allowed to mine.")
	}
	for i, v := range AddressList() {
		if common.HexToAddress(Addr) == v {
			index = i
			break
		}
	}
	list := NodeList(false)
	NodeID := list[index].(string)
	return keydir, filename, Addr, NodeID, nil
}

// Author implements consensus.Engine, returning the Ethereum address recovered
// from the signature in the header's extra-data section.
func (d *Dbft) Author(header *types.Header) (common.Address, error) {
	return ecrecover(header, d.signatures, d.isLight)
}

// VerifyHeader checks whether a header conforms to the consensus rules.
func (d *Dbft) VerifyHeader(chain consensus.ChainReader, header *types.Header, seal bool) error {
	return d.verifyHeader(chain, header, nil)
}

// VerifyHeaders is similar to VerifyHeader, but verifies a batch of headers. The
// method returns a quit channel to abort the operations and a results channel to
// retrieve the async verifications (the order is that of the input slice).

// This function is called by InsertChain() in blockchain.go
func (d *Dbft) VerifyHeaders(chain consensus.ChainReader, headers []*types.Header, seals []bool) (chan<- struct{}, <-chan error) {
	abort := make(chan struct{})
	results := make(chan error, len(headers))

	go func() {
		for i, header := range headers {
			err := d.verifyHeader(chain, header, headers[:i]) // Parents are not nil in this case.

			select {
			case <-abort:
				return
			case results <- err:
			}
		}
	}()
	return abort, results
}

// verifyHeader checks whether a header conforms to the consensus rules.The
// caller may optionally pass in a batch of parents (ascending order) to avoid
// looking those up from the database. This is useful for concurrently verifying
// a batch of new headers.
func (d *Dbft) verifyHeader(chain consensus.ChainReader, header *types.Header, parents []*types.Header) error {
	if header.Number == nil {
		return errUnknownBlock
	}
	number := header.Number.Uint64()

	// Don't waste time checking blocks from the future
	//log.Trace("check future header", "headerNum", header.Number, "coinbase", header.Coinbase, "headertime", header.Time, "now", time.Now().Unix())
	if header.Time.Cmp(big.NewInt(time.Now().Unix())) > 0 {
		return consensus.ErrFutureBlock
	}

	// // Checkpoint blocks need to enforce zero beneficiary
	checkpoint := (number % d.config.Epoch) == 0
	// checkpoint := (number % epochLength) == 0

	// if checkpoint && header.Coinbase != (common.Address{}) {
	// 	return errInvalidCheckpointBeneficiary
	// }

	// // Nonces must be 0x00..0 or 0xff..f, zeroes enforced on checkpoints
	// if !bytes.Equal(header.Nonce[:], nonceAuthVote) && !bytes.Equal(header.Nonce[:], nonceDropVote) {
	// 	return errInvalidVote
	// }
	// if checkpoint && !bytes.Equal(header.Nonce[:], nonceDropVote) {
	// 	return errInvalidCheckpointVote
	// }

	// Check that the extra-data contains both the vanity and signature
	if len(header.Extra) < extraVanity {
		return errMissingVanity
	}
	if len(header.Extra) < extraVanity+extraSeal {
		return errMissingSignature
	}
	// Ensure that the extra-data contains a signer list on checkpoint, while only one the signer otherwise
	signersBytes := len(header.Extra) - extraVanity - extraSeal
	signersCount := signersBytes / common.AddressLength
	extraSuffix := len(header.Extra) - extraSeal
	checkSigner := func(signersCount int) bool {
		for i := 0; i < signersCount; i++ {
			if !addrInSlice(common.BytesToAddress(header.Extra[extraVanity+common.AddressLength*i:extraSuffix]), AddressList()) {
				return false
			}
		}
		return true
	}
	if !checkpoint && signersBytes != common.AddressLength {
		return errExtraSigners
	} else if !checkpoint && !checkSigner(signersCount) {
		return errExtraUnknownSigners
	}
	// Make sure the Signers List is complete (Missing Signer)
	if checkpoint && signersBytes%common.AddressLength != 0 {
		return errInvalidCheckpointSigners
	} else if checkpoint && !checkSigner(signersCount) {
		return errExtraUnknownSigners
	}

	// Ensure that the mix digest is groupSigHash
	if len(header.MixDigest) != common.HashLength {
		return errInvalidMixDigest
	}
	// Ensure that the block doesn't contain any uncles which are meaningless in DBFT
	if header.UncleHash != uncleHash {
		return errInvalidUncleHash
	}
	// Ensure that the block's difficulty is meaningful (may not be correct at this point)
	if number > 0 {
		if header.Difficulty == nil || (header.Difficulty.Cmp(diff) != 0) {
			return errInvalidDifficulty
		}
	}
	// All basic checks passed, verify cascading fields
	return d.verifyCascadingFields(chain, header, parents)
}

// verifyCascadingFields verifies all the header fields that are not standalone,
// rather depend on a batch of previous headers. The caller may optionally pass
// in a batch of parents (ascending order) to avoid looking those up from the
// database. This is useful for concurrently verifying a batch of new headers.
func (d *Dbft) verifyCascadingFields(chain consensus.ChainReader, header *types.Header, parents []*types.Header) error {
	// The genesis block is the always valid dead-end
	number := header.Number.Uint64()
	if number == 0 {
		return nil
	}
	// Ensure that the block's timestamp isn't too close to it's parent
	var parent *types.Header
	if len(parents) > 0 {
		parent = parents[len(parents)-1]
	} else {
		parent = chain.GetHeader(header.ParentHash, number-1)
	}
	if parent == nil || parent.Number.Uint64() != number-1 || parent.Hash() != header.ParentHash {
		return consensus.ErrUnknownAncestor
	}
	if parent.Time.Uint64()+d.config.Period > header.Time.Uint64() {
		// if parent.Time.Uint64()+blockPeriod > header.Time.Uint64() {
		return ErrInvalidTimestamp
	}

	// Retrieve the snapshot needed to verify this header and cache it
	snap, err := d.SnapShot(chain, number-1, header.ParentHash, parents)
	if err != nil {
		return err
	}

	// If the block is a checkpoint block, verify the signer list
	if number%d.config.Epoch == 0 {
		// if number%epochLength == 0 {
		// Looks like a string storing Signers in cascading way
		missSigners := make([]common.Address, 0, len(AddressList()))
		missSignersOrder := make([]common.Address, 0, len(AddressList()))
		for _, v := range AddressList() {
			if !addrInSlice(v, snap.signers()) {
				missSigners = append(missSigners, v)
			}
		}
		missSignersOrder = ascending(missSigners)

		signers := make([]byte, len(missSignersOrder)*common.AddressLength)
		for i, signer := range missSignersOrder {
			copy(signers[i*common.AddressLength:], signer[:])
		}

		// Extra consists of extraVanity, missingSignersList + ActualSigner, extraSeal in order
		extraSuffix := len(header.Extra) - extraSeal
		if !bytes.Equal(header.Extra[extraVanity:extraSuffix-common.AddressLength], signers) {
			return errInvalidCheckpointSigners
		}
	}
	// All basic checks passed, verify the seal and return
	return d.verifySeal(chain, header, parents)
}

// VerifyUncles implements consensus.Engine, always returning an error for any
// uncles as this consensus mechanism doesn't permit uncles.
func (d *Dbft) VerifyUncles(chain consensus.ChainReader, block *types.Block) error {
	if len(block.Uncles()) > 0 {
		return errors.New("uncles not allowed")
	}
	return nil
}

// VerifySeal implements consensus.Engine, checking whether the signature contained
// in the header satisfies the consensus protocol requirements.
func (d *Dbft) VerifySeal(chain consensus.ChainReader, header *types.Header) error {
	return d.verifySeal(chain, header, nil)
}

// verifySeal checks whether the signature contained in the header satisfies the
// consensus protocol requirements. The method accepts an optional list of parent
// headers that aren't yet part of the local blockchain to generate the snapshots
// from.
func (d *Dbft) verifySeal(chain consensus.ChainReader, header *types.Header, parents []*types.Header) error {
	// Verifying the genesis block is not supported
	number := header.Number.Uint64()
	if number == 0 {
		return errUnknownBlock
	}

	// Retrieve the snapshot needed to verify this header and cache it
	snap, err := d.SnapShot(chain, number-1, header.ParentHash, parents)
	if err != nil {
		return err
	}

	// Resolve the authorization key and check against signers
	signer, err := ecrecover(header, d.signatures, true) // TODO, pretend being a light node
	if err != nil {
		return err
	}

	if _, ok := snap.Signers[signer]; !ok {
		return errUnauthorized
	}

	// if signer != header.Coinbase {
	// 	return errors.New("This block/header is not coming from current speaker")
	// }
	if number%d.config.Epoch != 0 {
		temp := common.BytesToAddress(header.Extra[extraVanity : extraVanity+common.AddressLength])
		if len(header.Extra) > extraVanity && signer != common.BytesToAddress(temp[:]) {
			log.Trace("cccccccccccccheck signers", "num", header.Number.Uint64(), "signer", common.ToHex(signer[:]), "data", common.ToHex(temp[:]))
			return errors.New("This block/header has an invalid signer")
		}
	}

	return nil
}

// SnapShot chain is always one block behind the canonical chain
func (d *Dbft) SnapShot(chain consensus.ChainReader, number uint64, hash common.Hash, parents []*types.Header) (*SnapShot, error) {
	// Search for a snapshot in memory or on disk
	var (
		headers []*types.Header
		snap    *SnapShot
	)
	for snap == nil {
		// log.Trace("Start to fetch a snapshot.")
		// If an in-memory snapshot was found, use that
		if s, ok := d.recentsSnaps.Get(hash); ok {
			snap = s.(*SnapShot)
			break
		}
		// If an on-disk snapshot can be found, use that
		if number%checkpointInterval == 0 {
			if s, err := loadSnapShot(d.config, d.signatures, d.db, hash); err == nil {
				//log.Trace("Loaded snapshot from disk", "number", number, "hash", hash)
				snap = s
				break
			}
		}
		// If we're at block zero, make a snapshot
		if number == 0 {
			genesis := chain.GetHeaderByNumber(0)
			if err := d.VerifyHeader(chain, genesis, false); err != nil {
				return nil, err
			}
			// The number of signers
			signers := make([]common.Address, (len(genesis.Extra)-extraVanity-extraSeal)/common.AddressLength)
			for i := 0; i < len(signers); i++ {
				copy(signers[i][:], genesis.Extra[extraVanity+i*common.AddressLength:])
			}

			snap = NewSnapShot(d.config, d.signatures, 0, genesis.Hash(), signers)
			if err := snap.store(d.db); err != nil {
				return nil, err
			}
			//log.Trace("Stored genesis snapshot to disk")
			break
		}
		// No snapshot for this header, gather the header and move backward
		var header *types.Header
		if len(parents) > 0 {
			// If we have explicit parents, pick from there (enforced)
			header = parents[len(parents)-1]
			if header.Hash() != hash || header.Number.Uint64() != number {
				return nil, consensus.ErrUnknownAncestor
			}
			// Shift out current parent
			parents = parents[:len(parents)-1]
		} else {
			// No explicit parents (or no more left), reach out to the database
			header = chain.GetHeader(hash, number)
			if header == nil {
				return nil, consensus.ErrUnknownAncestor
			}
		}
		headers = append(headers, header)
		number, hash = number-1, header.ParentHash
	}
	// Previous snapshot found, apply any pending headers on top of it
	// Revert the order of headers from descending to ascending
	for i := 0; i < len(headers)/2; i++ {
		headers[i], headers[len(headers)-1-i] = headers[len(headers)-1-i], headers[i]
	}
	snap, err := snap.apply(headers) // starting from genesis
	if err != nil {
		return nil, err
	}

	d.recentsSnaps.Add(snap.Hash, snap)

	// If we've generated a new checkpoint snapshot, save to disk
	if snap.Number%checkpointInterval == 0 && len(headers) > 0 {
		if err = snap.store(d.db); err != nil {
			return nil, err
		}
		//log.Trace("Stored snapshot to disk", "number", snap.Number, "hash", snap.Hash)
	}

	return snap, err
}

func (d *Dbft) Consensus(chain consensus.ChainReader, block *types.Block, proposedHeader *types.Header, proposedNum uint64, stop <-chan struct{}, signer common.Address, signFn SignerFn) (*types.Block, error) {

	snap, err := d.SnapShot(chain, proposedNum-1, proposedHeader.ParentHash, nil) // return the parent's snapshot
	if err != nil {
		return nil, err
	}

	keydir, filename, Addr, nodeid, err := d.getNodeConfig()
	if err != nil {
		return nil, err
	} else {
		// go d.eventMux.Post(GetLocalAddrEvent{Addr})
		go d.eventMux.Post(GetNodeIDEvent{nodeid})
	}
	prikey := getPrivateKey(keydir, filename, Addr, d.ctx.GetConfig().PassPhrase) //***

	deList := NewDelegatedList(chain, 0)

	viewForCount := deList.VIndex

	list := ModifiedAddr(deList.AddressListOrdered)

	cache := NewCacheConsensus()

	// timer := time.NewTimer(time.Second * time.Duration(d.config.Period))
	//	timer := time.NewTimer(time.Second * time.Duration(blockPeriod))

	iIndex := deList.AddressListOrdered[common.HexToAddress(Addr)]

	//randDelay := make([]uint64, 0, len(list))

	var (
		hasPreReq           bool
		hasBroadcastPreResp bool
		hasBeenCalled       bool
		// hasReceivedClose    bool
		delayCount int
	)

	start := make(chan uint64)      // for reminder of a starting point
	quit := make(chan bool)         // for miner.stop
	resetTimer := make(chan uint64) // for new view when timing out

	// gotOtherCh := make(chan uint64)
	doneCh := make(chan bool)
	// stopGeneratingBlockCh := make(chan *FinishConsensus)
	// finishCh := make(chan bool) // for closing current CloseEvent goroutine when receiving incoming block
	// closeCh := make(chan bool)                    // for closing current Other goroutine when receiving incoming block ***
	// closeCloseCh := make(chan bool)               // for closing current CloseEvent goroutine when generating new block ***
	// closeBeforeGenerateBlockCh := make(chan bool) // for closing current countDown delay when generating new block ***
	// closeAfterGenerateBlockCh := make(chan *types.Block) // for closing current Other goroutine when generating new block ***

	resultCh := make(chan *types.Block) // For new block
	changeCh := make(chan uint64)       // For changing view
	errorsCh := make(chan error)

	//FirstTimeFlag := time.Now() // For substract the delay

	// d.events = d.eventMux.Subscribe(GetPrepareReqEvent{}, GetPrepareRespEvent{}, GetChangeViewEvent{}, GetAdvertToCloseEvent{}, GetAdvertToNewViewEvent{}, sendBackToLoopEvent{}) //***
	// d.eventForBroadcast = d.eventMux.Subscribe(GetDelegatedResultEvent{})

	ConsensusNewTurn := func() {
		// d.events = d.eventMux.Subscribe(GetPrepareReqEvent{}, GetPrepareRespEvent{}, GetChangeViewEvent{}, GetAdvertToCloseEvent{}, GetAdvertToNewViewEvent{}, sendBackToLoopEvent{}) //***
		// d.eventForBroadcast = d.eventMux.Subscribe(GetDelegatedResultEvent{})

		log.Trace("Current Status", "p", deList.PIndex, "v", deList.VIndex, "i", iIndex)
		start <- deList.VIndex
		// close routine when miner.stop()
		go func() {
			select {
			case <-quit:
				return
			}
		}()

		go d.eventMux.Post(IsMiningEvent{true})

		if iIndex == deList.PIndex {
			d.events = d.eventMux.Subscribe(QuitMiningEvent{}, GetPrepareReqEvent{}, GetPrepareRespEvent{}, GetChangeViewEvent{}, GetAdvertToNewViewEvent{}) //***
			// d.eventForBroadcast = d.eventMux.Subscribe(GetDelegatedResultEvent{})
			log.Trace("Local is the speaker in this turn. ")

			headerHash := sigHash(proposedHeader) // 32B
			if prikey == nil {
				return
			}
			sig, err := crypto.Sign(headerHash[:], prikey)
			if err != nil {
				errorsCh <- err
				return
			}

			deList.IsSpeaker = true

			select { // wait for a blockperiod
			case <-time.After(time.Second * time.Duration(d.config.Period)):
				log.Trace("Send new PrepareReq Event.")
				control, _ := NewPrepareReq(deList, d.config, d.signatures, chain, block, sig)
				// randDelay = control.Get().RandDelay // Assign the randDelay
				cache.prepareRequests[common.HexToAddress(Addr)] = control.Get()
				go d.eventMux.Post(PrepareReqEvent{
					PreReq:      control.Get(),
					SpeakerFlag: control.SpeakerFlag,
				})
			}

			go func(block *types.Block) {
				for obj := range d.events.Chan() {
					// log.Trace("Check eventTime/Type when Chan()", "time", obj.Time, "type", reflect.TypeOf(obj.Data))
					switch ev := obj.Data.(type) {
					case QuitMiningEvent:
						doneCh <- true
					case GetPrepareRespEvent:
						if hasBeenCalled {
							log.Trace("Local has been asked to send already")
							break
						}
						if !hasBroadcastPreResp {
							log.Trace("GetPrepareRespEvent has been received as a speaker in Consensus().")
							log.Trace("Check delist", "p", deList.PIndex, "v", deList.VIndex)
							prepareResp := ev.PreResp // receive preResp
							// make sure get preReq before receiving preResp
							//						if !reflect.DeepEqual(prepareResp.Block, block) {
							//log.Trace("Check!!!", "hasPreReq", hasPreReq, "hasBroadcastPreResp", hasBroadcastPreResp)
							if prepareResp.Block.Hash() != block.Hash() {
								log.Trace("hash does not matched", "respBlock", prepareResp.Block.Hash(), "localBlock", block.Hash())
								break
							}
							if err := d.verify(chain, deList, prepareResp); err != nil {
								break
							}
							cache.prepareResponses[list[prepareResp.IIndex]] = prepareResp
						}
					case GetChangeViewEvent:
						log.Trace("GetChangeViewEvent has been received as a speaker in Consensus().")
						log.Trace("Check delist", "p", deList.PIndex, "v", deList.VIndex)
						control_changeV := ev.ChangeV // receive ChangeView
						if err := d.verify(chain, deList, control_changeV); err != nil {
							break
						}
						cache.changeViews[list[control_changeV.Get().IIndex]] = control_changeV.Get()

						viewnew := d.twoThirdChangeV(cache.changeViews, len(list))

						if viewnew != 0 {
							log.Trace("A new View has been activated", "viewnew", viewnew)
							d.broadcastNewView(viewnew, chain, deList, Addr, prikey) // **
							changeCh <- viewnew                                      // return the new view number
							return                                                   //quit the current goroutine
						}
						log.Trace("There is NO enough nodes going for the new View")
					case GetAdvertToNewViewEvent: //**
						log.Trace("GetAdvertToNewViewEvent has been received as a speaker in Consensus().")
						log.Trace("Check delist", "p", deList.PIndex, "v", deList.VIndex)
						control_newV := ev.ViewNew // receive ChangeView
						if err := d.verify(chain, deList, control_newV); err != nil {
							break
						}
						changeCh <- control_newV.Get().ViewNew // return the new view number
						return                                 //quit the current goroutine
					}

					// Count
					if !d.config.Test {
						if len(cache.prepareResponses) >= (len(list)-(len(list)-1)/3) && !hasBroadcastPreResp {
							if hasBeenCalled {
								log.Trace("Local has been asked to send already")
								break
							}
							preBlock := block
							// prevent replicated new block casuing forking
							if height := chain.CurrentHeader().Number.Uint64(); height != preBlock.Number().Uint64()-1 {
								return
							}
							newHeader := preBlock.Header()

							// GroupSig
							groupSig := make([]*types.GroupSignature, 0, len(cache.prepareResponses))

							for _, preResp := range cache.prepareResponses {
								sig := types.NewGroupSignature(preResp.IIndex, preResp.SignedHeader)
								groupSig = append(groupSig, sig)
							}
							// newHeader.MixDigest = types.CalcGroupSigHash(groupSig)
							newHeader.MixDigest = types.EmptySigHash
							intermediateblock := preBlock.WithSeal(newHeader)
							intermediateblock.AddGroupSignature(groupSig)

							// Add signers and return for further signing
							newBlock := d.addSigner(snap, deList, intermediateblock, iIndex)
							hasBeenCalled = true
							hasBroadcastPreResp = true
							resultCh <- newBlock
							return
						}
					} else {
						log.Trace("Check preResp", "preResp", len(cache.prepareResponses), "has?", hasBroadcastPreResp)
						if len(cache.prepareResponses) >= 1 && !hasBroadcastPreResp {
							if hasBeenCalled {
								log.Trace("Local has been asked to send already")
								break
							}
							preBlock := block
							// prevent replicated new block casuing forking
							if height := chain.CurrentHeader().Number.Uint64(); height != preBlock.Number().Uint64()-1 {
								return
							}
							newHeader := preBlock.Header()

							// GroupSig
							groupSig := make([]*types.GroupSignature, 0, len(cache.prepareResponses))

							for _, preResp := range cache.prepareResponses {
								sig := types.NewGroupSignature(preResp.IIndex, preResp.SignedHeader)
								groupSig = append(groupSig, sig)
							}
							// newHeader.MixDigest = types.CalcGroupSigHash(groupSig)
							newHeader.MixDigest = types.EmptySigHash
							intermediateblock := preBlock.WithSeal(newHeader)
							intermediateblock.AddGroupSignature(groupSig)

							// Add signers and return for further signing
							newBlock := d.addSigner(snap, deList, intermediateblock, iIndex)
							hasBeenCalled = true
							hasBroadcastPreResp = true
							resultCh <- newBlock
							return
						}
					}
				}
			}(block)

		} else {
			d.events = d.eventMux.Subscribe(QuitMiningEvent{}, GetPrepareReqEvent{}, GetPrepareRespEvent{}, GetChangeViewEvent{}, GetAdvertToNewViewEvent{}) //***
			// d.eventForBroadcast = d.eventMux.Subscribe(GetDelegatedResultEvent{})
			deList.IsSpeaker = false
			log.Trace("Local is the delegator in this turn. ")

			go func(block *types.Block) {
				for obj := range d.events.Chan() {
					// log.Trace("Check eventTime/Type when Chan()", "time", obj.Time, "type", reflect.TypeOf(obj.Data))
					switch ev := obj.Data.(type) {
					case QuitMiningEvent:
						doneCh <- true
					case GetPrepareReqEvent:
						if hasBeenCalled {
							log.Trace("Local has been asked to send already")
							break
						}
						log.Trace("GetPrepareReqEvent has been received as a delegator in Consensus().")
						log.Trace("Check delist", "p", deList.PIndex, "v", deList.VIndex)
						prepareReq := ev.PreReq // receive preReq
						if err := d.verify(chain, deList, prepareReq); err != nil {
							// changeview. No return here so that the original view properly runs before the changeView process being finished
							viewForCount = d.changeView(viewForCount, chain, deList, Addr, prikey)
							resetTimer <- viewForCount
							break
						}
						// randDelay = prepareReq.RandDelay // Assign the randDelay
						// send preResp
						cache.prepareRequests[list[prepareReq.PIndex]] = prepareReq

						deList.cache = &cachePreReq{Block: prepareReq.Block, hasPreReq: true}
						hasPreReq = true

						header := prepareReq.Block.Header()
						headerHash := sigHash(header) // 32B
						sig, err := crypto.Sign(headerHash[:], prikey)
						if err != nil {
							errorsCh <- err
							return
						}
						control, _ := NewPrepareResp(deList, Addr, d.config, d.signatures, chain, prepareReq.Block, sig)
						go d.eventMux.Post(PrepareRespEvent{
							PreResp:     control.Get(),
							SpeakerFlag: control.SpeakerFlag,
						})
					case GetPrepareRespEvent:
						if hasBeenCalled {
							log.Trace("Local has been asked to send already")
							break
						}
						if !hasBroadcastPreResp {
							log.Trace("GetPrepareRespEvent has been received as a delegator in Consensus().")
							log.Trace("Check delist", "p", deList.PIndex, "v", deList.VIndex)
							prepareResp := ev.PreResp // receive preResp
							// make sure get preReq before receiving preResp
							if !hasPreReq {
								break
							} else if prepareResp.Block.Hash() != deList.cache.Block.Hash() {
								log.Trace("hash does not matched", "respBlock", prepareResp.Block.Hash(), "cacheBlock", deList.cache.Block.Hash())
								break
							}
							if err := d.verify(chain, deList, prepareResp); err != nil {
								break
							}
							cache.prepareResponses[list[prepareResp.IIndex]] = prepareResp
						}
					case GetChangeViewEvent:
						log.Trace("GetChangeViewEvent has been received as a delegator in Consensus().")
						log.Trace("Check delist", "p", deList.PIndex, "v", deList.VIndex)
						control_changeV := ev.ChangeV // receive ChangeView
						if err := d.verify(chain, deList, control_changeV); err != nil {
							break
						}
						cache.changeViews[list[control_changeV.Get().IIndex]] = control_changeV.Get()

						viewnew := d.twoThirdChangeV(cache.changeViews, len(list))
						if viewnew != 0 {
							log.Trace("A new View has been activated", "viewnew", viewnew)
							d.broadcastNewView(viewnew, chain, deList, Addr, prikey) // **
							changeCh <- viewnew                                      // return the new view number
							return                                                   //quit the current goroutine
						}
						log.Trace("There is NO enough nodes going for the new View")
					case GetAdvertToNewViewEvent: //**
						log.Trace("GetAdvertToNewViewEvent has been received as a delegator in Consensus().")
						log.Trace("Check delist", "p", deList.PIndex, "v", deList.VIndex)
						control_newV := ev.ViewNew // receive ChangeView
						if err := d.verify(chain, deList, control_newV); err != nil {
							break
						}
						changeCh <- control_newV.Get().ViewNew // return the new view number
						return                                 // quit the current goroutine
					}

					// Count
					if !d.config.Test {
						if len(cache.prepareResponses) >= (len(list)-(len(list)-1)/3) && !hasBroadcastPreResp {
							// Allow to sign the block, wait for our time.
							if hasBeenCalled {
								log.Trace("Local has been asked to send already")
								break
							}
							preBlock := deList.cache.Block
							if height := chain.CurrentHeader().Number.Uint64(); height != preBlock.Number().Uint64()-1 {
								//log.Trace("Incorrect Height", "height", height, "msgHeight", preBlock.Number().Uint64()-1)
								return
							}

							if !hasPreReq {
								log.Trace("Have not yet received any PreReq msg.")
								continue
							}
							newHeader := preBlock.Header()

							// GroupSig
							groupSig := make([]*types.GroupSignature, 0, len(cache.prepareResponses))

							for _, preResp := range cache.prepareResponses {
								sig := types.NewGroupSignature(preResp.IIndex, preResp.SignedHeader)
								groupSig = append(groupSig, sig)
							}
							//newHeader.MixDigest = types.CalcGroupSigHash(groupSig)
							newHeader.MixDigest = types.EmptySigHash
							intermediateblock := preBlock.WithSeal(newHeader)
							intermediateblock.AddGroupSignature(groupSig)

							// Add signers and return for further signing
							newBlock := d.addSigner(snap, deList, intermediateblock, iIndex)

							hasBeenCalled = true
							hasBroadcastPreResp = true
							resultCh <- newBlock
							return //quit the current goroutine

						}
					} else {
						log.Trace("Check preResp", "preResp", len(cache.prepareResponses), "has?", hasBroadcastPreResp)
						if len(cache.prepareResponses) >= 1 && !hasBroadcastPreResp {
							// Allow to sign the block, wait for our time.
							if hasBeenCalled {
								log.Trace("Local has been asked to send already")
								break
							}
							preBlock := deList.cache.Block
							if height := chain.CurrentHeader().Number.Uint64(); height != preBlock.Number().Uint64()-1 {
								//log.Trace("Incorrect Height", "height", height, "msgHeight", preBlock.Number().Uint64()-1)
								return
							}

							if !hasPreReq {
								log.Trace("Have not yet received any PreReq msg.")
								continue
							}
							newHeader := preBlock.Header()

							// GroupSig
							groupSig := make([]*types.GroupSignature, 0, len(cache.prepareResponses))

							for _, preResp := range cache.prepareResponses {
								sig := types.NewGroupSignature(preResp.IIndex, preResp.SignedHeader)
								groupSig = append(groupSig, sig)
							}
							//newHeader.MixDigest = types.CalcGroupSigHash(groupSig)
							newHeader.MixDigest = types.EmptySigHash
							intermediateblock := preBlock.WithSeal(newHeader)
							intermediateblock.AddGroupSignature(groupSig)

							// Add signers and return for further signing
							newBlock := d.addSigner(snap, deList, intermediateblock, iIndex)

							hasBeenCalled = true
							hasBroadcastPreResp = true
							resultCh <- newBlock
							return //quit the current goroutine
						}
					}
				}
			}(block)
		}
	}

	go ConsensusNewTurn()

	for {
		select {
		case <-doneCh: // triggered by ChainHeadEvent -> QuitMiningEvent
			quit <- true
			go d.eventMux.Post(IsMiningEvent{false})
			go d.eventMux.Post(ResetIsSpeakerEvent{false})
			return nil, nil
		case <-stop:
			quit <- true
			go d.eventMux.Post(IsMiningEvent{false})
			go d.eventMux.Post(ResetIsSpeakerEvent{false})
			// d.closeChannel()
			return nil, nil
		case <-time.After(time.Second * time.Duration(math.Pow(2, float64(viewForCount)+1)*float64(d.config.Period))):
			// case <-time.After(time.Second * time.Duration(math.Pow(2, float64(viewForCount)+1)*float64(blockPeriod))): // timeout
			log.Trace("Changing View.")
			delayCount += 1
			viewForCount = d.changeView(viewForCount, chain, deList, Addr, prikey)
		case viewNum := <-resetTimer:
			log.Trace("Reset Timer.", "viewForCount", viewNum)
		case i := <-start:
			log.Trace("A new round is running", "view", i)
		case newBlock := <-resultCh:
			quit <- true // pending
			log.Trace("New block has been created locally. ")
			log.Trace("Check Header", "header", newBlock.Hash())
			go d.eventMux.Post(IsMiningEvent{false})
			go d.eventMux.Post(ResetIsSpeakerEvent{false})
			// d.closeChannel()
			return newBlock, nil
		case newView := <-changeCh:
			quit <- true // pending
			select {     // wait for a while
			case <-time.After(time.Second * 3):
			}
			// Initialize everything
			deList = NewDelegatedList(chain, newView)
			cache = NewCacheConsensus()
			viewForCount = deList.VIndex
			hasPreReq = false
			hasBroadcastPreResp = false
			hasBeenCalled = false
			// hasReceivedClose = false
			log.Trace("New View is done. Start for a new round.")
			go d.eventMux.Post(ResetIsSpeakerEvent{false})
			d.closeChannel()
			go ConsensusNewTurn()
		case err := <-errorsCh:
			quit <- true // pending
			go d.eventMux.Post(IsMiningEvent{false})
			go d.eventMux.Post(ResetIsSpeakerEvent{false})
			// d.closeChannel()
			return nil, err
		}
	}
}

func (d *Dbft) closeChannel() {
	d.events.Unsubscribe()
	//d.eventForBroadcast.Unsubscribe()
}

// viewForCount == 0 in the beginning. Return the new ViewNum
func (d *Dbft) changeView(viewForCount uint64, chain consensus.ChainReader, deList *DelegatedList, addr string, prikey *ecdsa.PrivateKey) uint64 {
	changeV, _ := NewChangeView(viewForCount, deList, addr, chain, prikey)
	go d.eventMux.Post(ChangeViewEvent{
		ChangeV: changeV,
		// SpeakerFlag: control.SpeakerFlag,
	})
	return changeV.Get().ViewNew
}

func (d *Dbft) broadcastNewView(newView uint64, chain consensus.ChainReader, deList *DelegatedList, addr string, prikey *ecdsa.PrivateKey) { //**
	newV, _ := NewBroadcastNewView(newView, deList, addr, chain, prikey)
	go d.eventMux.Post(AdvertToNewViewEvent{
		ViewNew: newV,
	})
}

func (d *Dbft) twoThirdChangeV(chV map[common.Address]*ChangeView, N int) uint64 {
	for addr, cv := range chV {
		fmt.Println("i = ", addrIndex(addr, AddressList()), "oldV = ", cv.View, "newV = ", cv.ViewNew)
	}
	changeV := make([]uint64, 0, len(chV))
	count := make(map[uint64]int)
	for _, v := range chV {
		changeV = append(changeV, v.ViewNew)
	}
	for _, v := range changeV {
		count[v] += 1
	}
	for k, v := range count {
		if !d.config.Test {
			if v >= (N-(N-1)/3) && k > 0 {
				return uint64(k)
			}
		} else {
			if v >= 2 && k > 0 {
				return uint64(k)
			}
		}
	}
	return 0
}

func (d *Dbft) verify(chain consensus.ChainReader, deList *DelegatedList, msg interface{}) error {
	log.Trace("Start to run verify().")
	switch msg := msg.(type) {
	case *PrepareRequest:
		if height := chain.CurrentHeader().Number.Uint64(); height != msg.Height {
			//log.Trace("Incorrect Height", "height", height, "msgHeight", msg.Height)
			return errors.New("Height does not match.")
		}
		if view := deList.VIndex; view != msg.View {
			//log.Trace("Incorrect View", "view", view, "msgView", msg.View)
			return errors.New("View does not match.")
		}
		if int(msg.PIndex) >= len(deList.AddressListOrdered) || msg.PIndex != deList.PIndex {
			//log.Trace("Incorrect P", "msgP", msg.PIndex, "delistP", deList.PIndex)
			return errors.New("AddressID does not exist.")
		}
		list := ModifiedAddr(deList.AddressListOrdered)
		speakerAddr := list[msg.PIndex]

		if signerAddr, _ := pubKeyrecover(msg.Block.Header(), msg.SignedHeader); signerAddr != speakerAddr {
			//log.Trace("Incorrect Sign", "signerAddr", signerAddr, "speakerAddr", speakerAddr)
			return errors.New("Signature does not match.")
		}
		if _, err := d.validateTx(msg.Block.Transactions()); err != nil {
			//log.Trace("Invalid Transaction", "transactionHash", txhash, "err", err)
			return err
		}
		if _, err := d.validateContent(chain, msg.Block, speakerAddr); err != nil {
			//log.Trace("Invalid Block", "blockhash", hash, "error", err)
			return err
		}

	case *PrepareResponse:
		if height := chain.CurrentHeader().Number.Uint64(); height != msg.Height {
			//log.Trace("Incorrect Height", "height", height, "msgHeight", msg.Height)
			return errors.New("Height does not match.")
		}
		if view := deList.VIndex; view != msg.View {
			//log.Trace("Incorrect View", "view", view, "msgView", msg.View)
			return errors.New("View does not match.")
		}
		if int(msg.IIndex) >= len(deList.AddressListOrdered) {
			//log.Trace("Incorrect I", "msgI", msg.IIndex)
			return errors.New("AddressID does not exist.")
		}
		list := ModifiedAddr(deList.AddressListOrdered)
		delegateAddr := list[msg.IIndex]

		if signerAddr, _ := pubKeyrecover(msg.Block.Header(), msg.SignedHeader); signerAddr != delegateAddr {
			//log.Trace("Incorrect Sign", "signerAddr", signerAddr, "delegateAddr", delegateAddr)
			return errors.New("Signature does not match.")
		}

	case *ControlChangeV:
		changeV := msg.Get()
		if height := chain.CurrentHeader().Number.Uint64(); height != changeV.Height {
			//log.Trace("Incorrect Height", "height", height, "msgHeight", changeV.Height)
			return errors.New("Height does not match.")
		}
		if int(changeV.IIndex) >= len(deList.AddressListOrdered) {
			//log.Trace("Incorrect I", "msgI", changeV.IIndex)
			return errors.New("AddressID does not exist.")
		}
		list := ModifiedAddr(deList.AddressListOrdered)
		delegateAddr := list[changeV.IIndex]

		if signerAddr, _ := pubKeyrecoverFromChangeV(changeV, msg.SignedChangeV); signerAddr != delegateAddr {
			//log.Trace("Incorrect Sign", "signerAddr", signerAddr, "delegateAddr", delegateAddr)
			return errors.New("Signature does not match.")
		}

	case *ControlNewViewBroadCast: //**
		newV := msg.Get()
		if height := chain.CurrentHeader().Number.Uint64(); height != newV.Height {
			//log.Trace("Incorrect Height", "height", height, "msgHeight", newV.Height)
			return errors.New("Height does not match.")
		}
		if int(newV.PIndex) >= len(deList.AddressListOrdered) || newV.PIndex != deList.PIndex {
			//log.Trace("Incorrect P", "msgP", newV.PIndex, "delistP", deList.PIndex)
			return errors.New("AddressID does not exist.")
		}
		if view := deList.VIndex; view != newV.VIndex {
			//log.Trace("Incorrect View", "view", view, "msgView", newV.VIndex)
			return errors.New("View does not match.")
		}
		if int(newV.IIndex) >= len(deList.AddressListOrdered) {
			//log.Trace("Incorrect I", "msgI", newV.IIndex)
			return errors.New("AddressID does not exist.")
		}
		list := ModifiedAddr(deList.AddressListOrdered)
		delegateAddr := list[newV.IIndex]

		if signerAddr, _ := pubKeyrecoverFromNewV(newV, msg.Sig); signerAddr != delegateAddr {
			//log.Trace("Incorrect Sign", "signerAddr", signerAddr, "delegateAddr", delegateAddr)
			return errors.New("Signature does not match.")
		}
	}
	log.Trace("Finish verify().")
	return nil
}

func (d *Dbft) validateContent(chain consensus.ChainReader, block *types.Block, speaker common.Address) (common.Hash, error) {
	d.lock.RLock()
	defer d.lock.RUnlock()

	header := block.Header()
	hash := block.Hash()
	number := header.Number.Uint64()
	parent := chain.GetHeader(header.ParentHash, number-1)
	// Number
	if header.Number == nil {
		return hash, errUnknownBlock
	}
	if parent == nil || parent.Number.Uint64() != number-1 || parent.Hash() != header.ParentHash {
		return hash, consensus.ErrUnknownAncestor
	}
	// Coinbase
	if speaker != header.Coinbase {
		return hash, errors.New("Incorrent coinbase")
	}
	// Time
	if parent.Time.Uint64()+d.config.Period > header.Time.Uint64() {
		// if parent.Time.Uint64()+blockPeriod > header.Time.Uint64() {
		return hash, ErrInvalidTimestamp
	}
	// Extradata
	if len(header.Extra) < extraVanity {
		return hash, errMissingVanity
	}
	if len(header.Extra) < extraVanity+extraSeal {
		return hash, errMissingSignature
	}
	if len(header.Extra[extraVanity:]) != extraSeal || !bytes.Equal(header.Extra[extraVanity:], make([]byte, extraSeal)) {
		return hash, errors.New("Incorrect initial Signature field")
	}
	// Uncle
	if header.UncleHash != uncleHash {
		return hash, errInvalidUncleHash
	}
	if len(block.Uncles()) > 0 {
		return hash, errors.New("uncles not allowed")
	}
	// Transaction
	if hash := types.DeriveSha(block.Transactions()); hash != header.TxHash {
		return hash, fmt.Errorf("transaction root hash mismatch: have %x, want %x", hash, header.TxHash)
	}
	// GroupSig
	emptyGroupSig := types.EmptySigHash
	if len(header.MixDigest) != common.HashLength || header.MixDigest != emptyGroupSig {
		return hash, errInvalidMixDigest
	}
	if len(block.GroupSignatures()) > 0 {
		return hash, errors.New("PrepareRequest should not contain any GroupSigs")
	}
	// Diff
	if number > 0 {
		if header.Difficulty == nil || (header.Difficulty.Cmp(diff) != 0) {
			return hash, errInvalidDifficulty
		}
	}
	// Nonce
	nonce := types.BlockNonce{}
	if header.Nonce != nonce {
		return hash, errors.New("Not all-zero nonce")
	}
	// State, Bloom and Receipts
	envState, _ := chain.StateAt(parent.Root)
	envVmConfig := vm.Config{}
	receipts, _, usedGas, err := chain.ProcessorDBFT().Process(block, envState, envVmConfig)
	if err != nil {
		return common.Hash{}, err
	}
	err = chain.ValidatorDBFT().ValidateState(block, chain.GetBlock(block.ParentHash(), block.NumberU64()-1), envState, receipts, usedGas)
	if err != nil {
		return common.Hash{}, err
	}

	// ALL GOOD!
	log.Trace("Content validation passes.")
	return common.Hash{}, nil
}

func (d *Dbft) validateTx(txs []*types.Transaction) (common.Hash, error) {
	d.lock.RLock()
	defer d.lock.RUnlock()

	if d.txPool == nil {
		return common.Hash{}, errors.New("Txpool has not been fetched")
	}

	for _, tx := range txs {
		if err := d.txPool.ValidateTx(tx, false); err != nil {
			return tx.Hash(), errors.New("Transaction validation fails")
		}
		// if exist := d.txPool.Get(tx.Hash()); exist == nil {
		// 	return tx.Hash(), errors.New("Transaction does not exist")
		// }
	}
	log.Trace("Txs validation passes.")
	return common.Hash{}, nil
}

// Add the current signer (P) to extradata field, while every Epoch blocks, add the signers that have never signed
func (d *Dbft) addSigner(snap *SnapShot, deList *DelegatedList, block *types.Block, index uint64) *types.Block {
	log.Trace("Start to run addSigner().")
	header := block.Header()
	number := header.Number.Uint64()
	list := ModifiedAddr(deList.AddressListOrdered)
	missSigners := make([]common.Address, 0, len(list))
	missSignersOrder := make([]common.Address, 0, len(list))

	if number%d.config.Epoch == 0 {
		// if number%epochLength == 0 {
		// tranverse the snapshot
		for k, _ := range deList.AddressListOrdered {
			if !addrInSlice(k, snap.signers()) {
				missSigners = append(missSigners, k)
			}
		}
		missSignersOrder = ascending(missSigners)
		for _, missSigner := range missSignersOrder {
			// add the addrs of missing signers
			header.Extra = insertSigner(header.Extra, missSigner[:])
		}
		signer := list[index]
		// add the addr of acutal signer at the end
		header.Extra = insertSigner(header.Extra, signer[:])

	} else {
		// speaker := list[deList.PIndex]
		// // add the addr of the current speaker
		// header.Extra = insertSigner(header.Extra, speaker[:])
		signer := list[index]
		// add the addr of acutal signer at the end
		header.Extra = insertSigner(header.Extra, signer[:])
	}

	log.Trace("Finish addSigner(). Return new block to local!!!")
	return block.WithSeal(header)
}

func insertSigner(initial []byte, insert []byte) []byte {
	temp := make([]byte, extraSeal)
	copy(temp, initial[len(initial)-extraSeal:])
	initial = append(initial[:len(initial)-extraSeal], insert...)
	initial = append(initial, temp...)
	return initial
}

// Prepare implements consensus.Engine, preparing all the consensus fields of the
// header for running the transactions on top.
func (d *Dbft) Prepare(chain consensus.ChainReader, header *types.Header) error {
	log.Trace("Start to run Prepare().")
	number := header.Number.Uint64()

	// Nonce is reserved for now, set to empty
	header.Nonce = types.BlockNonce{}
	// Mix digest is reserved for groupSig
	// header.MixDigest = common.Hash{}
	header.MixDigest = types.EmptySigHash
	// Difficulty is set to 1
	header.Difficulty = diff

	// Ensure the extra data has all it's components
	if len(header.Extra) < extraVanity {
		header.Extra = append(header.Extra, bytes.Repeat([]byte{0x00}, extraVanity-len(header.Extra))...) // add zeros to fillup to 32
	}
	header.Extra = header.Extra[:extraVanity]

	// // This will be done after the consensus is done
	// if number%d.config.Epoch == 0 {
	// 	for _, signer := range snap.signers() {
	// 		header.Extra = append(header.Extra, signer[:]...)
	// 	}
	// }
	header.Extra = append(header.Extra, make([]byte, extraSeal)...)

	// Ensure the timestamp has the correct delay
	parent := chain.GetHeader(header.ParentHash, number-1)
	if parent == nil {
		return consensus.ErrUnknownAncestor
	}
	header.Time = new(big.Int).Add(parent.Time, new(big.Int).SetUint64(d.config.Period))
	// header.Time = new(big.Int).Add(parent.Time, new(big.Int).SetUint64(blockPeriod))
	if header.Time.Int64() < time.Now().Unix() {
		header.Time = big.NewInt(time.Now().Unix())
	}

	return nil
}

// Authorize injects a private key into the consensus engine to mint new blocks
// with.
func (d *Dbft) Authorize(signer common.Address, signFn SignerFn) {
	d.lock.Lock()
	defer d.lock.Unlock()
	log.Trace("Start to run Authorize().")
	d.signer = signer
	d.signFn = signFn // accounts/keystore/keystore.go line 257 SignHash() -> crypto.Sign(hash, privkey)
}

// Seal implements consensus.Engine, attempting to create a sealed block using
// the local signing credentials.
func (d *Dbft) Seal(chain consensus.ChainReader, block *types.Block, stop <-chan struct{}) (*types.Block, error) {
	log.Trace("Start to run Seal().")
	header := block.Header()

	// Sealing the genesis block is not supported
	number := header.Number.Uint64()
	if number == 0 {
		return nil, errUnknownBlock
	}
	// Don't hold the signer fields for the entire sealing procedure
	d.lock.RLock()
	signer, signFn := d.signer, d.signFn
	d.lock.RUnlock()

	log.Trace("Start to fetch txpool")

	if d.txPool == nil {
		// log.Trace("txpool", "txpool", d.txPool)
		for obj := range d.eventForTxPool.Chan() {
			switch ev := obj.Data.(type) {
			case GetTxPoolEvent:
				log.Trace("Receive GetTxPoolEvent!!!")
				d.txPool = ev.Txpool
				goto StartToConsensus
			}
		}
	}

StartToConsensus:
	log.Trace("Start to run Consensus().")
	newBlock, err := d.Consensus(chain, block, header, number, stop, signer, signFn)
	log.Trace("Indicate how may goroutine", "number", runtime.NumGoroutine())
	if err != nil {
		return nil, err
	}
	log.Trace("Consensus() ends.")
	d.closeChannel()

	if newBlock == nil {
		log.Trace("Consensus Stop or Someone else created the new block. Wait for the next round.")
		return nil, nil
	}

	newHeader := newBlock.Header()

	sighash, err := signFn(accounts.Account{Address: signer}, sigHash(newHeader).Bytes()) // this sigHash including the signer field, differing to HashDBFT()
	if err != nil {
		return nil, err
	}

	copy(newHeader.Extra[len(newHeader.Extra)-extraSeal:], sighash) // fulfill the extraSeal with sighash signed by local addr

	log.Trace("Seal() ends.")
	return newBlock.WithSeal(newHeader), nil
}

// Finalize implements consensus.Engine, ensuring no uncles are set, nor block
// rewards given, and returns the final block.
func (d *Dbft) Finalize(chain consensus.ChainReader, header *types.Header, state *state.StateDB, txs []*types.Transaction, uncles []*types.Header, receipts []*types.Receipt) (*types.Block, error) {
	log.Trace("Start to run Finalize().")

	header.Root = state.IntermediateRoot(chain.Config().IsEIP158(header.Number))
	header.UncleHash = types.CalcUncleHash(nil)
	// Assemble and return the final block for sealing
	return types.NewBlock(header, txs, nil, receipts, nil), nil
}

// CalcDifficulty is the difficulty adjustment algorithm. It returns the difficulty
// that a new block should have based on the previous blocks in the chain and the
// current signer.
func (d *Dbft) CalcDifficulty(chain consensus.ChainReader, time uint64, parent *types.Header) *big.Int {
	return big.NewInt(1)
}

func (d *Dbft) GetConsensusConfig() params.ConsensusConfig {
	return d.config
}

// APIs implements consensus.Engine, returning the user facing RPC API to allow
// controlling the signer signing.
func (d *Dbft) APIs(chain consensus.ChainReader) []rpc.API {
	return []rpc.API{{
		Namespace: "dbft",
		Version:   "1.0",
		Service:   &API{chain: chain, dbft: d},
		Public:    false,
	}}
}
