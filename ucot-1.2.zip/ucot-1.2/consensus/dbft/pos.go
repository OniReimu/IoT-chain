// Copyright 2017 The go-ethereum Authors
// This file is part of the go-ethereum library.
//
// The go-ethereum library is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// The go-ethereum library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with the go-ethereum library. If not, see <http://www.gnu.org/licenses/>.

// Package dbft implements the delegated bft consensus engine.

package dbft

import (
	"math"
	"math/big"
	"sort"

	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/consensus"
	"github.com/ethereum/go-ethereum/core/state"
	// "github.com/ethereum/go-ethereum/core/types"
	"github.com/ethereum/go-ethereum/log"
)

var (
	// Block reward in wei for successfully mining a block
	initialBlockReward *big.Int = totalAmountToken("100000000000000000000") // 100 UBI
	tokenTotal         *big.Int = totalAmountToken("210000000000000000000000000")

	deadTime = uint64(3153600000) // 100 years

	winnerRate = 50 // The 50% richest signers
)

// totalAmountToken represents the total amount of token released
func totalAmountToken(amount string) *big.Int {
	a := new(big.Int)
	result, _ := a.SetString(amount, 10)
	return result
}

// (Rewards)
// ∧
// |---------------  (initialBlockReward)
// |              |
// |              |
// |______________|______________
// |              |             |
// |              |-------------|-------------
// |              |             |            |-------------.....____________
// ⊥---------------------------------------------------------z-------------⊥--->   (Height)
//          (divHeight64)                                              (deadHeight)
func variableRewards(blockPeriod uint64, headerHeight uint64) *big.Int {
	div := new(big.Int)
	deadHeight := deadTime / (blockPeriod + MinePeriod)
	if headerHeight > deadHeight {
		return big.NewInt(0)
	}
	div.Div(tokenTotal, initialBlockReward)
	divHeight64 := div.Uint64() / 2
	divisor := math.Pow(2, float64((headerHeight / divHeight64)))
	return big.NewInt(int64(initialBlockReward.Uint64() / uint64(divisor)))

	// var y float64
	// power := big.NewInt(int64(math.Pow(10, 18)))
	// bigY := new(big.Int)

	// x := headerHeight
	// y = math.Pow(float64(x), float64(1.0/8.2902))
	// y = -y
	// y += float64((initialBlockReward + 1))
	// intY := math.Floor(y)
	// if intY < 1 {
	// 	return big.NewInt(0)
	// }
	// bigY.Mul(power, big.NewInt(int64(intY)))

	// return bigY
}

func AccumulateRewards(chain consensus.ChainReader, list []common.Address, state *state.StateDB, blockPeriod uint64) (*big.Int, []common.Address) {
	var winners []common.Address

	rewardForSpeaker := new(big.Int)
	rewardForFirst := new(big.Int)
	rewardForSecond := new(big.Int)
	rewardForThird := new(big.Int)

	parentHeader := chain.CurrentHeader()
	parentHeight := parentHeader.Number.Uint64()
	// log.Trace("Track the height of current header", "height", parentHeight)
	// log.Trace("Track the height of Finalize header", "height", header.Number.Uint64())
	if parentHeight == 0 {
		log.Trace("No reward for the genesis block")
		return nil, nil
	}
	winners = append(winners, getWinner(list, state, winnerRate)...) // descending has been applied here.
	reward := variableRewards(blockPeriod, parentHeight)
	rewardForSpeaker.Div(reward, big.NewInt(2))          // 50% accounts for the rewards for speaker
	rewardForFirst.Div(rewardForSpeaker, big.NewInt(2))  // 50% * 50%
	rewardForSecond.Div(rewardForSpeaker, big.NewInt(3)) // 50% * 30%
	rewardForThird.Div(rewardForSpeaker, big.NewInt(5))  // 50% * 20%
	// 50% 10 15 25 (0.2, 0.3, 0.5)  100 = 50 30 20
	for i, addr := range winners {
		if float64(i) < float64(len(winners))*0.2 {
			state.AddBalance(addr, rewardForFirst)
		} else if float64(i) < float64(len(winners))*0.2+float64(len(winners))*0.3 {
			state.AddBalance(addr, rewardForSecond)
		} else { // *0.5
			state.AddBalance(addr, rewardForThird)
		}
	}
	log.Trace("check reward", "total", reward, "speaker", rewardForSpeaker, "1st", rewardForFirst, "2nd", rewardForSecond, "3rd", rewardForThird)
	state.AddBalance(parentHeader.Coinbase, rewardForSpeaker)
	return reward, winners
}

func Punishment(fine *big.Int, winners []common.Address, punished common.Address, state *state.StateDB) {
	state.SubBalance(punished, fine) // if...else

	compensation := new(big.Int)
	compensation.Div(fine, big.NewInt(int64(len(winners))))
	for _, addr := range winners {
		state.AddBalance(addr, compensation)
	}
	log.Trace("check punishment", "fine", fine, "compensation", compensation)
}

type Balance struct {
	index   int
	balance *big.Int
}

type BalanceWrapper struct {
	balance []Balance
	by      func(p, q *Balance) bool
}

type SortBy func(p, q *Balance) bool

func (bw BalanceWrapper) Len() int           { return len(bw.balance) }
func (bw BalanceWrapper) Swap(i, j int)      { bw.balance[i], bw.balance[j] = bw.balance[j], bw.balance[i] }
func (bw BalanceWrapper) Less(i, j int) bool { return bw.by(&bw.balance[i], &bw.balance[j]) }
func SortBalance(balance []Balance, by SortBy) {
	sort.Sort(BalanceWrapper{balance, by})
}
func aescOrdesc(flag int, x, y *big.Int) bool {
	if flag < 0 { // ascending
		switch x.Cmp(y) {
		case -1: // x < y
			return true
		default:
			return false
		}
	} else { // descending
		switch x.Cmp(y) {
		case 1: // x > y
			return true
		default:
			return false
		}
	}
}

// Here the list are the signers that attended to the (n-1)th process of group signature.
func getWinner(list []common.Address, state *state.StateDB, winnerRate int) []common.Address {
	winnerNum := len(list) * 50 / 100
	balances := make([]Balance, 0, len(list))
	for i, addr := range list {
		balances = append(balances, Balance{index: i, balance: state.GetBalance(addr)}) // not a pointer here
	}
	SortBalance(balances, func(p, q *Balance) bool {
		return aescOrdesc(1, p.balance, q.balance) // descending
	})

	winningSigners := make([]common.Address, 0, winnerNum)
	for _, balance := range balances[:winnerNum] {
		winningSigners = append(winningSigners, list[balance.index])
	}
	log.Trace("check how many winners", "list", len(list), "winner", len(winningSigners))
	return winningSigners
}
