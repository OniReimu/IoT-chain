// Copyright 2017 The go-ethereum Authors
// This file is part of the go-ethereum library.
//
// The go-ethereum library is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// The go-ethereum library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with the go-ethereum library. If not, see <http://www.gnu.org/licenses/>.

package dbft

import (
	// "errors"
	// "math/big"
	"bytes"
	"encoding/json"
	// "fmt"
	// "math/rand"
	// "time"

	// "github.com/ethereum/go-ethereum/accounts"
	"github.com/ethereum/go-ethereum/common"
	// "github.com/ethereum/go-ethereum/consensus"
	"github.com/ethereum/go-ethereum/core/types"
	"github.com/ethereum/go-ethereum/ethdb"
	// "github.com/ethereum/go-ethereum/crypto"
	// "github.com/ethereum/go-ethereum/event"
	// "github.com/ethereum/go-ethereum/p2p/discover"
	// "github.com/ethereum/go-ethereum/log"
	"github.com/ethereum/go-ethereum/params"
	// // "github.com/ethereum/go-ethereum/crypto/sha3"
	// // "github.com/ethereum/go-ethereum/rlp"
	lru "github.com/hashicorp/golang-lru"
)

type SnapShot struct {
	config   *params.DbftConfig
	sigcache *lru.ARCCache

	// currentParam *DelegatedList

	Number  uint64                    `json:"number"`
	Hash    common.Hash               `json:"hash"`
	Signers map[common.Address]uint64 `json:"signers"` //***
	//Signers map[common.Address]struct{} `json:"signers"`

}

func NewSnapShot(config *params.DbftConfig, sigcache *lru.ARCCache, number uint64, hash common.Hash, signers []common.Address) *SnapShot {
	snap := &SnapShot{
		config:   config,
		sigcache: sigcache,
		Number:   number,
		Hash:     hash,
		Signers:  make(map[common.Address]uint64), //***
		//Signers:  make(map[common.Address]struct{}),
	}
	for _, signer := range signers {
		snap.Signers[signer] = 0 //***
		//snap.Signers[signer] = struct{}{}
	}
	return snap
}

// loadSnapshot loads an existing snapshot from the database.
func loadSnapShot(config *params.DbftConfig, sigcache *lru.ARCCache, db ethdb.Database, hash common.Hash) (*SnapShot, error) {
	blob, err := db.Get(append([]byte("dbft-"), hash[:]...))
	if err != nil {
		return nil, err
	}
	snap := new(SnapShot)
	if err := json.Unmarshal(blob, snap); err != nil {
		return nil, err
	}
	snap.config = config
	snap.sigcache = sigcache

	return snap, nil
}

// store inserts the snapshot into the database.
func (s *SnapShot) store(db ethdb.Database) error {
	blob, err := json.Marshal(s)
	if err != nil {
		return err
	}
	return db.Put(append([]byte("dbft-"), s.Hash[:]...), blob)
}

// copy creates a deep copy of the snapshot.
func (s *SnapShot) copy() *SnapShot {
	cpy := &SnapShot{
		config:   s.config,
		sigcache: s.sigcache,
		Number:   s.Number,
		Hash:     s.Hash,
		Signers:  make(map[common.Address]uint64), //***
		// Signers:  make(map[common.Address]struct{}),
	}
	for signer, count := range s.Signers { //***
		cpy.Signers[signer] = count
	}
	// for signer := range s.Signers {
	// 	cpy.Signers[signer] = struct{}{}
	// }
	return cpy
}

// apply creates a new authorization snapshot by applying the given () to
// the original one.
func (s *SnapShot) apply(headers []*types.Header) (*SnapShot, error) {
	// Allow passing in no headers for cleaner code
	if len(headers) == 0 {
		return s, nil
	}
	// Sanity check that the headers can be applied
	for i := 0; i < len(headers)-1; i++ {
		if headers[i+1].Number.Uint64() != headers[i].Number.Uint64()+1 {
			return nil, errInvalidSnapShotChain
		}
	}
	if headers[0].Number.Uint64() != s.Number+1 {
		return nil, errInvalidSnapShotChain
	}
	// Iterate through the headers and create a new snapshot
	snap := s.copy()

	for _, header := range headers {
		// signer, err := ecrecover(header, s.sigcache)
		// if err != nil {
		// 	return nil, err
		// }
		extraSuffix := len(header.Extra) - extraSeal
		signer := common.BytesToAddress(header.Extra[extraSuffix-common.AddressLength : extraSuffix]) // signer, who broadcasts the newblock
		if _, ok := snap.Signers[signer]; !ok {
			return nil, errUnauthorized
		}
		// Accumulate the count ***
		snap.Signers[signer] += 1
		// for k, v := range snap.Signers {
		// 	log.Trace("Check signers in apply()", "key", k, "value", v)
		// }
		// signers get recorded every Epoch blocks. Initialised back to zero
		if header.Number.Uint64()%s.config.Epoch == 0 {
			for k, _ := range snap.Signers {
				snap.Signers[k] = 0 //***
				//delete(snap.Signers, k)
			}
		}
	}
	snap.Number += uint64(len(headers))
	snap.Hash = headers[len(headers)-1].Hash()

	return snap, nil
}

// signers retrieves the list of authorized signers in ascending order.
func (s *SnapShot) signers() []common.Address {
	signers := make([]common.Address, 0, len(s.Signers))
	for signer := range s.Signers {
		signers = append(signers, signer)
	}
	signersOrder := ascending(signers)
	return signersOrder
}

func ascending(addr []common.Address) []common.Address {
	for i := 0; i < len(addr); i++ {
		for j := i + 1; j < len(addr); j++ {
			if bytes.Compare(addr[i][:], addr[j][:]) > 0 {
				addr[i], addr[j] = addr[j], addr[i]
			}
		}
	}
	return addr
}
