// Copyright 2017 The go-ethereum Authors
// This file is part of the go-ethereum library.
//
// The go-ethereum library is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// The go-ethereum library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with the go-ethereum library. If not, see <http://www.gnu.org/licenses/>.

package dbft

import (
	// "errors"
	// "math/big"
	// "bytes"
	// "encoding/json"
	// "fmt"
	"math/rand"
	"time"

	// "github.com/ethereum/go-ethereum/accounts"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/consensus"
	"github.com/ethereum/go-ethereum/core/types"
	// "github.com/ethereum/go-ethereum/ethdb"
	// "github.com/ethereum/go-ethereum/crypto"
	// "github.com/ethereum/go-ethereum/event"
	// "github.com/ethereum/go-ethereum/p2p/discover"
	// "github.com/ethereum/go-ethereum/log"
	// "github.com/ethereum/go-ethereum/params"
	// // "github.com/ethereum/go-ethereum/crypto/sha3"
	// // "github.com/ethereum/go-ethereum/rlp"
	// lru "github.com/hashicorp/golang-lru"
)

type cachePreReq struct {
	Block     *types.Block
	hasPreReq bool
}

type cacheConsensus struct { // may need to be refreshed once a consensus starting over
	prepareRequests  map[common.Address]*PrepareRequest
	prepareResponses map[common.Address]*PrepareResponse
	changeViews      map[common.Address]*ChangeView
}

type DelegatedList struct {
	AddressListOrdered map[common.Address]uint64
	PIndex             uint64
	VIndex             uint64
	IsSpeaker          bool
	cache              *cachePreReq
}

func NewDelegatedList(chain consensus.ChainReader, v uint64) *DelegatedList {
	list := AddressList()
	delegatedList := &DelegatedList{
		// AddressListOrdered: Randomized(list),
		AddressListOrdered: NoRandomized(list),
		PIndex:             (chain.CurrentHeader().Number.Uint64() - v) % uint64(len(list)),
		VIndex:             v,
		IsSpeaker:          false,
	}
	return delegatedList
}

func NewCacheConsensus() *cacheConsensus {
	return &cacheConsensus{
		prepareRequests:  make(map[common.Address]*PrepareRequest),
		prepareResponses: make(map[common.Address]*PrepareResponse),
		changeViews:      make(map[common.Address]*ChangeView),
	}
}

func NoRandomized(list []common.Address) map[common.Address]uint64 {
	newList := make(map[common.Address]uint64)

	for index, value := range list {
		newList[value] = uint64(index)
	}
	return newList
}

func Randomized(list []common.Address) /*map[common.Address]uint64*/ []uint64 {
	nums := GenerateRandomNumber(0, len(list), len(list))

	//newList := make(map[common.Address]uint64)
	newList := make([]uint64, 0, len(list))

	for _, value := range nums {
		// newList[list[index]] = uint64(value)
		newList = append(newList, uint64(value))
	}
	return newList
}

// func Randomized(list []common.Address) map[common.Address]uint64 {
// 	nums := GenerateRandomNumber(0, len(list), len(list))

// 	newList := make(map[common.Address]uint64)

// 	for index, value := range nums {
// 		newList[list[index]] = uint64(value)

// 	}
// 	return newList
// }

// Create random number in [start,end)
func GenerateRandomNumber(start int, end int, count int) []int {

	if end < start || (end-start) < count {
		return nil
	}

	nums := make([]int, 0)

	r := rand.New(rand.NewSource(time.Now().UnixNano()))
	for len(nums) < count {

		num := r.Intn((end - start)) + start

		exist := false
		for _, v := range nums {
			if v == num {
				exist = true
				break
			}
		}
		if !exist {
			nums = append(nums, num)
		}
	}
	return nums
}

func ModifiedAddr(id map[common.Address]uint64) map[uint64]common.Address {
	modified := make(map[uint64]common.Address)
	for k, v := range id {
		modified[v] = k
	}
	return modified
}

func (delegated *DelegatedList) IncreaseV() uint64 {
	delegated.VIndex = delegated.VIndex + 1
	return delegated.VIndex
}
