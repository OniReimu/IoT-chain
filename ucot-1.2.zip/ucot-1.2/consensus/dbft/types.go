// Copyright 2017 The go-ethereum Authors
// This file is part of the go-ethereum library.
//
// The go-ethereum library is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// The go-ethereum library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with the go-ethereum library. If not, see <http://www.gnu.org/licenses/>.

package dbft

import (
	// "errors"
	// "math/big"
	// "reflect"
	"crypto/ecdsa"
	"github.com/ethereum/go-ethereum/crypto/sha3"
	"math/big" //***

	// "github.com/ethereum/go-ethereum/accounts"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/consensus"
	"github.com/ethereum/go-ethereum/core/types"
	"github.com/ethereum/go-ethereum/crypto"
	// "github.com/ethereum/go-ethereum/node"
	// "github.com/ethereum/go-ethereum/p2p/discover"
	"github.com/ethereum/go-ethereum/params"
	// "github.com/ethereum/go-ethereum/crypto/sha3"
	// "github.com/ethereum/go-ethereum/log"
	"github.com/ethereum/go-ethereum/rlp"
	lru "github.com/hashicorp/golang-lru"
)

// TxPool wraps all methods required for retrieve the txpool
type TxPool interface { //***
	GasPrice() *big.Int
	Stats() (int, int)
	AddLocal(*types.Transaction) error
	AddRemote(*types.Transaction) error
	Get(common.Hash) *types.Transaction

	ValidateTx(*types.Transaction, bool) error
	Pending() (map[common.Address]types.Transactions, error)
}

type QuitMiningEvent struct{}

// type GetLocalAddrEvent struct{ Addr string }
type GetNodeIDEvent struct{ NodeID string }

type GetTxPoolEvent struct{ Txpool TxPool } //***

// DbftEvent:

type IsMiningEvent struct{ Flag bool }
type ResetIsSpeakerEvent struct{ SpeakerFlag bool }

type PrepareReqEvent struct {
	PreReq      *PrepareRequest
	SpeakerFlag bool
}
type GetPrepareReqEvent struct{ PreReq *PrepareRequest }

type PrepareRespEvent struct {
	PreResp     *PrepareResponse
	SpeakerFlag bool
}
type GetPrepareRespEvent struct{ PreResp *PrepareResponse }

type ChangeViewEvent struct{ ChangeV *ControlChangeV }
type GetChangeViewEvent struct{ ChangeV *ControlChangeV }

// type ReadyToBroadCastEvent struct{ SignedFromDelegate *SendBackToSpeaker }
// type GetDelegatedResultEvent struct{ SignedFromDelegate *SendBackToSpeaker }

// type AdvertToCloseEvent struct{ Finish *FinishConsensus }
// type GetAdvertToCloseEvent struct{ Finish *FinishConsensus }

type AdvertToNewViewEvent struct{ ViewNew *ControlNewViewBroadCast }
type GetAdvertToNewViewEvent struct{ ViewNew *ControlNewViewBroadCast }

// type sendBackToLoopEvent struct{ Block *types.Block } //***

// type SendBackToSpeaker struct {
// 	Block  *types.Block
// 	Sig    []byte
// 	PIndex uint64
// 	IIndex uint64
// 	VIndex uint64
// }

// type FinishConsensus struct {
// 	Header *types.Header
// 	Sig    []byte
// 	PIndex uint64
// 	IIndex uint64
// 	VIndex uint64
// }

type NewViewBroadCast struct { // **
	ViewNew uint64
	// For validation
	Height uint64
	PIndex uint64
	IIndex uint64
	VIndex uint64
}

type ControlNewViewBroadCast struct { //**
	NewView *NewViewBroadCast
	Sig     []byte
}

type PrepareRequest struct {
	Height       uint64
	View         uint64
	PIndex       uint64
	Block        *types.Block
	SignedHeader []byte
	RandDelay    []uint64
	// RandDelay map[common.Address]uint64
}

type ControlPreReq struct {
	config      *params.DbftConfig
	sigcache    *lru.ARCCache
	SpeakerFlag bool

	prepareReq *PrepareRequest
}

type PrepareResponse struct {
	Height       uint64
	View         uint64
	IIndex       uint64
	Block        *types.Block
	SignedHeader []byte
}

type ControlPreResp struct {
	config      *params.DbftConfig
	sigcache    *lru.ARCCache
	SpeakerFlag bool

	prepareResp *PrepareResponse
}

type ChangeView struct {
	Height  uint64
	View    uint64
	IIndex  uint64
	ViewNew uint64
}

type ControlChangeV struct {
	//	config  *params.DbftConfig
	ChangeV *ChangeView

	SignedChangeV []byte
}

// The sigcache is often the DBFT.signatures
func NewPrepareReq(delegated *DelegatedList, config *params.DbftConfig, sigcache *lru.ARCCache, chain consensus.ChainReader, block *types.Block, sig []byte) (*ControlPreReq, error) {

	preReq := &ControlPreReq{
		config:      config,
		sigcache:    sigcache,
		SpeakerFlag: delegated.IsSpeaker,
		prepareReq: &PrepareRequest{
			Height:       chain.CurrentHeader().Number.Uint64(),
			View:         delegated.VIndex,
			PIndex:       delegated.PIndex,
			Block:        block,
			SignedHeader: sig,
			RandDelay:    Randomized(AddressList()),
		},
	}
	return preReq, nil
}

func NewPrepareResp(delegated *DelegatedList, Addr string, config *params.DbftConfig, sigcache *lru.ARCCache, chain consensus.ChainReader, block *types.Block, sig []byte) (*ControlPreResp, error) {
	// headerHash := sigHash(header)
	// prikey := nodeConfig.NodeKey()
	// sig, err := crypto.Sign(headerHash[:], prikey)
	// if err != nil {
	// 	return nil, err
	// }
	// delegated := NewDelegatedList(chain, v)
	preResp := &ControlPreResp{
		config:      config,
		sigcache:    sigcache,
		SpeakerFlag: delegated.IsSpeaker,
		prepareResp: &PrepareResponse{
			Height: chain.CurrentHeader().Number.Uint64(),
			View:   delegated.VIndex,
			// IIndex:       delegated.AddressListOrdered[discover.PubkeyID(nodeConfig.P2P.PrivateKey.PublicKey)],
			IIndex:       delegated.AddressListOrdered[common.HexToAddress(Addr)],
			Block:        block,
			SignedHeader: sig,
		},
	}
	return preResp, nil
}

func NewChangeView(viewNum uint64, delegated *DelegatedList, Addr string, chain consensus.ChainReader, prikey *ecdsa.PrivateKey) (*ControlChangeV, error) {

	changeVinstance := &ChangeView{
		Height: chain.CurrentHeader().Number.Uint64(),
		// View:   delegated.VIndex,
		View:   viewNum,
		IIndex: delegated.AddressListOrdered[common.HexToAddress(Addr)],
		// ViewNew: delegated.VIndex + 1,
		ViewNew: viewNum + 1,
	}
	changeVhash := sigchangeV(changeVinstance)
	sig, _ := crypto.Sign(changeVhash[:], prikey)
	newV := &ControlChangeV{
		//		config:        config,
		ChangeV:       changeVinstance,
		SignedChangeV: sig,
	}
	return newV, nil
}

func NewBroadcastNewView(newView uint64, delegated *DelegatedList, Addr string, chain consensus.ChainReader, prikey *ecdsa.PrivateKey) (*ControlNewViewBroadCast, error) { //**

	newVinstance := &NewViewBroadCast{
		ViewNew: newView,
		Height:  chain.CurrentHeader().Number.Uint64(),
		PIndex:  delegated.PIndex,
		IIndex:  delegated.AddressListOrdered[common.HexToAddress(Addr)],
		VIndex:  delegated.VIndex,
	}
	newVhash := sigBroadcastNewV(newVinstance)
	sig, _ := crypto.Sign(newVhash[:], prikey)
	newV := &ControlNewViewBroadCast{
		NewView: newVinstance,
		Sig:     sig,
	}
	return newV, nil
}

func (control *ControlPreReq) Get() *PrepareRequest {
	return control.prepareReq
}

func (control *ControlPreResp) Get() *PrepareResponse {
	return control.prepareResp
}

func (control *ControlChangeV) Get() *ChangeView {
	return control.ChangeV
}

func (control *ControlNewViewBroadCast) Get() *NewViewBroadCast { //**
	return control.NewView
}

func sigchangeV(changeV *ChangeView) (hash common.Hash) {
	hasher := sha3.NewKeccak256()

	rlp.Encode(hasher, []interface{}{
		changeV.Height,
		changeV.View,
		changeV.IIndex,
		changeV.ViewNew,
	})
	hasher.Sum(hash[:0])
	return hash
}

func sigBroadcastNewV(NewV *NewViewBroadCast) (hash common.Hash) { // **
	hasher := sha3.NewKeccak256()

	rlp.Encode(hasher, []interface{}{
		NewV.ViewNew,
		NewV.Height,
		NewV.PIndex,
		NewV.IIndex,
		NewV.VIndex,
	})
	hasher.Sum(hash[:0])
	return hash
}
