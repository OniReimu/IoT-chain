// Copyright 2017 The go-ethereum Authors
// This file is part of the go-ethereum library.
//
// The go-ethereum library is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// The go-ethereum library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with the go-ethereum library. If not, see <http://www.gnu.org/licenses/>.

package dbft

import (
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/p2p/discover"
)

const (
	IDLength = 64
)

func BytesToID(temp []byte) *discover.NodeID {
	var id *discover.NodeID
	id.SetBytes(temp)
	return id
}
func HexToID(flag bool, s string) interface{} {
	if flag == true {
		return BytesToID(common.FromHex(s)) // 64B
	} else {
		return s[:16] // matched with eth/peers
	}

}

// func NodeList(flag bool) []interface{} {
// 	return []interface{}{
// 		HexToID(flag, "5356a777b264fa91f98be802a191a9d174e99ae06796e5c81d8eb0b8906d87e2816f9711af7d6d8ad05f1576b7ee05665dd054a9d63381fc7e1356ac5dc9ff06"),
// 		HexToID(flag, "265e8d13a74799081e327315f3304b65094eab5ed025446a7b6f945d99a7eb548b500ab4789033c167913719831f15cebb2eedf037d09b9cd6642d93defc4db1"),
// 		HexToID(flag, "d444d2cc697d1177a28b292334ddb5c7777a6a4a8f41d7aea985ae6fa0d7e56a5224e565a5893684b05e70773fcad32fc68c154d85c6195382d0394f577a76a1"),
// 		HexToID(flag, "49ceda730266523b7336d2b8ba75a5f33ee39320ea39fdac60457a8d2ae7bd382c3cc41baa1208ced2d5bb7b6360596dcc40bf75ddc563458952cf2fca4a3bda"),
// 		HexToID(flag, "3f4c6ab6381ca4bdca29aacf53e4d550c833f79306c07af2a6a2e6735c138cc99d45351e4138ec812efcb33c4dac423c51cbb749d83a6cda8c4529ecba546359"),
// 		HexToID(flag, "155e15b97fadb59995199e548ed0830e32a14e250578d59c1a66ebfea506584f57774e2574b856bcbcf2a5f966d3814913aa9816b2f24d059dfd4277bf6ed7d1"),
// 		HexToID(flag, "b88fcd6413d90bb9dae1e83b5f7170a66c57f9debea32d1038e388f16f471849aa07de66255878345e90a6781878951602a2871273a438621785a299044fae2e"),
// 		HexToID(flag, "341e90069e4b43b6af62c3537613d817bc13aa8cff0e462335f029b49822626fe0839002e1384034b9dc63195a725f81e4f96080e12266081ff36b7cc7c999a1"),
// 		HexToID(flag, "4c93fb9b279c59ec40653f878a9f20ab15d929a4d2976f576963df9fc918323ff20b10b5f0ba6df9a81be4fad959de44706490b1e0c1ceaabad94d99aab02ed6"),
// 	}
// }

// func AddressList() []common.Address {
// 	return []common.Address{
// 		common.HexToAddress("bd100d9898d346f34702107c068d58f9544e71c2"),
// 		common.HexToAddress("341429c4dab021481e8f090bdf9875ccb460e298"),
// 		common.HexToAddress("4912266771caea9ebd12bc8196e0171036a15165"),
// 		common.HexToAddress("ecf60b92bf23bd1b44e9b0b8ab689a3b9753ec0c"),
// 		common.HexToAddress("bcbc8dd0b0561ca83d0a80d6f0936f2adabb9f54"),
// 		common.HexToAddress("ecd255997c37a2f204df9adbd10582d058f2f3ce"),
// 		common.HexToAddress("a2ca89662ceda4bfa9b42700426d773ab6fedb9f"),
// 		common.HexToAddress("3bc4fbfec7f3913c461a1e481a40fca09e56e087"),
// 		common.HexToAddress("9b8a8f625672bfb087b931660f925068f5b7298f"),
// 	}
// }

func NodeList(flag bool) []interface{} {
	return []interface{}{
		HexToID(flag, "2c5eadf74d01642aa3d097f17409c29f331e69f57af5efa0eb6c04c0fd99c27c01b83cb2be4d24bb452c8f2963b9b2bf9c604d5af28f23927da279c0448c0a43"),
		HexToID(flag, "926dbb15bdeaf61dceb03973ffa0949790176e77f6175b35b967ffe7549cc5224f9aa4be0ba06c4e9d0f7636d8ca57e506d122115a48289a234c656477205abb"),
		HexToID(flag, "6811ed72fe6e8c0a1e0fabf9354d63eb88d41a3a03e29ebfa8c1370b97d12829a00e3658ee412b1db60c55c3b146ec64c080b61b2297e490b2e5b64a787cb074"),
		HexToID(flag, "5174c9c9b8acac7032d7d640ffd111e7338e5983bbd5558a09f28dc6bfe861b94811dd4921180616f22e0fc9c6eb0195f13bb6948b6436f2c76f3ab7c493af52"),
		HexToID(flag, "850698f599268e2c1f24a2622a45a8c27da8e6d019b2dde2f91a20276921fbed1850fbc807560e0e73f4f691c3a3134dc6ced424457d600a1eccb5a6319dc6be"),
		HexToID(flag, "c04fa31198d7c53c5656a8bb3da44e810d8471dda2ca16ec820166b28afa1bf4ac302ec1e2ed55f35e99b8fce01c804e4541e897f9d8a445d0f7104bcf4b3632"),
		HexToID(flag, "d52c4e4cb19ebbaa2e5da8ffc2e53f8946bbb72a231d4c69c54975afc64405d44b41dd50e1d21df73af78ab536d923b33d19f528bc96c20fc99e126290bd848e"),
		HexToID(flag, "b1fdaa68a712b7a6eb19b7a65f5989eef9265eb03964f2c8d1211f7ca9ed3edc6c4cc02a551609e8bf8213419da131670586fdf0a172ab706554b0cc15abc782"),
		HexToID(flag, "96cc3de968bc9d9cc1e9ad3b666a643a22aa2298bddee25eee5f297a4e76b1b41cca1f102d2c7e98f36c039cc00011e0ab98f17c6349bcc9d11c4362755d596e"),
		HexToID(flag, "cfcc92b94a573417eaf169c7e3e522ebc9ec64c0d504617a535eec7e271fd73d2da0444dbe2ce4d78407e645687484acf49926e25cd06b7e436438f3eb744e47"),
		HexToID(flag, "0a8592d58844f2294c4257fd4e956a0641724eeed682e876042b89e10162fbe8d9bc021e95d8648d7a74faf0729f98ed057348390165c6d98b7983e90d33b2be"),
		HexToID(flag, "e755b4984883fd9ce6c23303a4140f8765ff9785a02557eb2b69900214edf8be8b2a3e0e1674ab11a6823556d1472019682c91194e4cde9088c96e63871c5a27"),
		HexToID(flag, "0d722aee45eb5410c2b12e7463291d1927b343d299e3156e214b4f21e05bf29b1bf8c9e0e9b14b6a6a2a63d5ee5e7835e76ecc9d23285303589baaf0e76d7473"),
		HexToID(flag, "a7271bba18c4b4930c55079faedf6feefc5711664ca2899d669c379ff775c85d4252760ab0fc6849001067a135790a1c5a24e42c854079fcdbff5cc19d54a6e1"),
		HexToID(flag, "6891392629699ae49716367704bb2f86af843d240c591b2a2741b2cf14f6dd2f22925f2b047a91507ce737895b2d1b101137be6542f0e5cc8ac5963f950711f3"),
		HexToID(flag, "61f8912455a978363e325d7896954d06e7d65e707463f5666083e35cc59d290efd6a509740154ec4b7fd8320aec4ace513185a21c4997fdb04965919265c7bef"),
		HexToID(flag, "77b80a0969eb9b8bdc7f0038b75a50ed467760cf9a6f0e6d0318867772d79169b2c1efa60b9d312a40a9e79c665feb654de41b8eaa92d2757121c177f69c43ed"),
		HexToID(flag, "dbbe98e6a0baec8e3f88243402ed19df36baabe79352fd48dc1073c6a007b6cd2a6dffcd1545d90cbe51754f20da47b70847e1edc10894a9b5c574944859be5d"),
		HexToID(flag, "33fd523e9de3d91db272dbd064ac9e7d7d1418c008cd817a793e33c2e5a4e80a580fe0a664977c4be5dd3a74e8925f9086138b80a03d07e854847bd0a6a70f3c"),
		HexToID(flag, "e79b41ff72b0a4822e98b922a30e6eaa8ff687d0a84bce23d5a44e97fd06763f965ff62aedf75613952ffdf00a4c41e981b3b146e1e017f1e0b86fc5277f3b1c"),
	}
}

func AddressList() []common.Address {
	return []common.Address{
		common.HexToAddress("4f36bb3506249fced0260add3b8a6fa3cf5a38c2"),
		common.HexToAddress("7e64abb068b3f0d733b2b09ac6513901ba911a36"),
		common.HexToAddress("1d2015c93784bad766e4bf1885e67c9235469207"),
		common.HexToAddress("194ab55dfbed65ae5cf2e7bae80685b9dde81b85"),
		common.HexToAddress("068a178e520f5820c655be1c33a0459d9c03645b"),
		common.HexToAddress("44be08bab5e1feed627324526488783482a54e3a"),
		common.HexToAddress("0824434ee5f9824c223a219f7f9844e83f3b909b"),
		common.HexToAddress("70ba2ce6908aa29bc189a5163730645232ae6b74"),
		common.HexToAddress("118d076caba530bf626b534ed3e97c67e86fe850"),
		common.HexToAddress("bcfd42e587131b6f79adc7686efb89e6a4c85f5b"),
		common.HexToAddress("78cea6f4b8a67d465e4cf1a64067f9881633ae3d"),
		common.HexToAddress("f628001249b9fa5a92210ce90628fafa000fd898"),
		common.HexToAddress("36e768bf73e7663e5b0cae362efc5396cc31e346"),
		common.HexToAddress("1c9f5801c9ce7585aebc44650272aa2e31478fee"),
		common.HexToAddress("9f363d4a9881d261fcd60762a09fda86e1ad7580"),
		common.HexToAddress("d00e1e81750019e0fb8fcd1a0fba059bf5f1d572"),
		common.HexToAddress("6c2e7d889f2753d55aebf62b1fa4c71adc92b1e5"),
		common.HexToAddress("42d7f2f4f7ea3ac78dcbc14d8542d665889a735b"),
		common.HexToAddress("e6c7f1e91331bc83f1261a0989712d16488ad3af"),
		common.HexToAddress("5ecb3363d8e1b88e89d1e8225dbf9aae379e0c40"),
	}
}

// func addrInMap(addr common.Address, signerList map[common.Address]struct{}) bool {
// 	for k, _ := range signerList {
// 		if k == addr {
// 			return true
// 		}
// 	}
// 	return false
// }

func addrInSlice(addr common.Address, signerList []common.Address) bool {
	for _, v := range signerList {
		if v == addr {
			return true
		}
	}
	return false
}

func IndexInSlice(index int, delegated []uint64) bool {
	for _, v := range delegated {
		if int(v) == index {
			return true
		}
	}
	return false
}

func addrIndex(addr common.Address, signerList []common.Address) int {
	for i, v := range signerList {
		if v == addr {
			return i
		}
	}
	return -1
}
